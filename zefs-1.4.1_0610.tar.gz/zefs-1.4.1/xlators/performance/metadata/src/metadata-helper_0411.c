/*
   Copyright (c) 2008-2012 Red Hat, Inc. <http://www.zecloud.cn>
   This file is part of ZeFS.

   This file is licensed to you under your choice of the GNU Lesser
   General Public License, version 3 or any later version (LGPLv3 or
   later), or the GNU General Public License, version 2 (GPLv2), in all
   cases as published by the Free Software Foundation.
*/
#ifndef _CONFIG_H
#define _CONFIG_H
#include "config.h"
#endif


//#if METADATA

#include "metadata.h"
//#include "options.h"
//#include "zefs3-xdr.h"

inline fsnode *fsnode_new (){
	fsnode * p = NULL;

	p = GF_CALLOC (1, sizeof(*p),gf_metadata_mt_fsnode_t);
	if (!p)
		goto out;

	//p->xattr_array->key = (char*)malloc (strlen(p->xattr_array->key));
	//p->xattr_array->value = (char*)malloc (strlen(p->xattr_array->value));

out:
	return p;
}

inline void fsnode_destroy (fsnode *p){
	if (p == NULL) {
		return;
	}
	GF_FREE (p);
	return;
}

inline fsedge *fsedge_new (){
	fsedge * p = NULL;
	p = GF_CALLOC (1, sizeof(*p),gf_metadata_mt_fsedge_t);

	p->name = GF_CALLOC (1, sizeof (char*), gf_metadata_mt_char);

	return p;
}

inline void fsedge_destroy (fsedge *p){
	if (p == NULL) {
		return;
	}
	GF_FREE (p);
	return;
}


void _add_fsnode_to_hash_table(fsnode *p, metadata_node_table_t *table) {
	uint32_t nodepos;
	fsnode **hashtable = table->hashtable;

	if (p == NULL || hashtable == NULL) {
		return;
	}	
	p->parents = NULL;
	nodepos = NODEHASHPOS(p->gfid);
	p->next = hashtable[nodepos];
	hashtable[nodepos] = p;
	
	table->nodes++;
	if (S_ISDIR (p->stat.st_mode)) {
		table->dirnodes++;
	} else {
		table->filenodes++;
	}
	return;
}


void add_fsnode_to_hash_table(fsnode *p, metadata_node_table_t *table) {

        if (!p || !table) {
                return;
        }

        LOCK (&table->lock);
        {
               _add_fsnode_to_hash_table(p, table);
        }
        UNLOCK (&table->lock);
        return;
}

void _remove_fsnode_from_hash_table(fsnode *p, metadata_node_table_t *table) {

}

void remove_fsnode_from_hash_table(fsnode *p, metadata_node_table_t *table) {

}

/* Add by hf@20150409 for convert */
fsnode *fsnodes_node_create(loc_t *loc,  gf_dirent_t  *entry ,fsedge *fseg)
{
	fsnode        *new_fsnd = NULL;
	uint32_t       par_idx, idx = 0;
	new_fsnd = fsnode_new();

	if (__is_root_gfid (loc->gfid)) {
		uuid_copy(new_fsnd->gfid, loc->gfid);
		//mt_stat_from_iatt(&new_fsnd->stat, &entry->d_stat);  
		//new_fsnd->xattr_array->value = NULL;
		//new_fsnd->xattr_array->key = NULL;
		new_fsnd->xattr_cnt = 3;
		new_fsnd->parents  = NULL;
		new_fsnd->children = NULL; 
		new_fsnd->next = NULL; 
		goto out;
	}

    par_idx = NODEHASHPOS(loc->pargfid);  /* 依据gfid判断目录或文件的落点在hash数组中那个索引 */
    idx = NODEHASHPOS(entry->inode->gfid);  /* 依据gfid判断目录或文件的落点在hash数组中那个索引 */
    //priv->table.hashtable[idx] = fsnode_new();

    uuid_copy(new_fsnd->gfid, entry->inode->gfid);
    mt_stat_from_iatt(&new_fsnd->stat, &entry->d_stat);
	//new_fsnd->xattr_array->value = NULL;  //待赋值 
	//new_fsnd->xattr_array->key = NULL;    //待赋值 
	new_fsnd->xattr_cnt = 1;

	new_fsnd->children = NULL;
	new_fsnd->parents = fseg;
	new_fsnd->next = NULL;
	//priv->table.hashtable[idx] = new_fsnd;

	if (!IA_ISDIR (entry->d_stat.ia_type))
	{
		new_fsnd->children = NULL;
		new_fsnd->next = NULL;
	}

out:
	return new_fsnd;
}

//fsedge *fsedges_edge_create(loc_t *loc, gf_dirent_t  *entry,  fsedge *fseg, metadata_private_t  *priv)
fsedge *fsedges_edge_create(loc_t *loc, gf_dirent_t  *entry,  
		fsedge *fseg, fsnode *fsnd)
{

	fsedge         *new_fseg = NULL;
	uint32_t       par_idx, idx = 0;
    new_fseg = fsedge_new();

	idx = NODEHASHPOS(loc->gfid);
	par_idx = NODEHASHPOS(loc->pargfid);
gf_log ("", GF_LOG_ERROR, "1------------------idx=[%d]--par_idx=[%d]--------", idx, par_idx);

	if (__is_root_gfid (loc->gfid) ) {
    	new_fseg->name = "/";
	    new_fseg->nleng = 1;
    	new_fseg->child = priv->table.hashtable[idx] ;
    	new_fseg->parent = NULL;
    	new_fseg->nextchild = NULL;

		goto out;
	}
    strcpy(new_fseg->name, entry->d_name);
    new_fseg->nleng = strlen(entry->d_name);
    new_fseg->child = priv->table.hashtable[idx] ;
    new_fseg->parent = priv->table.hashtable[par_idx];
    new_fseg->nextchild = NULL;
    new_fseg->nextparent = fseg;

    new_fseg->prevchild = NULL;
	new_fseg->prevparent = NULL;	

gf_log ("", GF_LOG_ERROR, "1------------------fsedge->name=[%s]-------", new_fseg->name);
out:
	return new_fseg;
}

inline void
mt_stat_from_iatt (struct stat *stat, struct iatt *iatt)
{
        stat->st_dev        = iatt->ia_dev;
        stat->st_ino        = iatt->ia_ino;

        stat->st_mode       = st_mode_from_ia (iatt->ia_prot, iatt->ia_type);

        stat->st_nlink      = iatt->ia_nlink;
        stat->st_uid        = iatt->ia_uid;
        stat->st_gid        = iatt->ia_gid;

        stat->st_rdev       = makedev (ia_major (iatt->ia_rdev),
                                       ia_minor (iatt->ia_rdev));

        stat->st_size       = iatt->ia_size;
        stat->st_blksize    = iatt->ia_blksize;
        stat->st_blocks     = iatt->ia_blocks;

        stat->st_atime      = iatt->ia_atime;
        ST_ATIM_NSEC_SET (stat, iatt->ia_atime_nsec);

        stat->st_mtime      = iatt->ia_mtime;
        ST_MTIM_NSEC_SET (stat, iatt->ia_mtime_nsec);

        stat->st_ctime      = iatt->ia_ctime;
        ST_CTIM_NSEC_SET (stat, iatt->ia_ctime_nsec);

}

void showfsnode(metadata_private_t  *priv)
{
	int i = 0;
gf_log ("", GF_LOG_ERROR, "<------------------------------------Begin----------------------------------->");

gf_log ("", GF_LOG_ERROR, "<--------priv->nodes=[%d]", priv->table.nodes);
gf_log ("", GF_LOG_ERROR, "<--------priv->dirnodes=[%d]", priv->table.dirnodes);
gf_log ("", GF_LOG_ERROR, "<--------priv->filenodes=[%d]", priv->table.filenodes);
//gf_log ("", GF_LOG_ERROR, "<--------priv->total_metadata_mem=[%ld]", priv->table.total_metadata_mem);
	for(i=0; i<(1<<16); i++)
	{
		if(priv->table.hashtable[i] != NULL)
		{
			gf_log ("", GF_LOG_ERROR, "<-------fsedge->name=[%p], i=[%d]", priv->table.hashtable[i], i);
//			gf_log ("", GF_LOG_ERROR, "<-------fsedge->name=[%s]", priv->table.hashtable[i]->children->name);
		}
	}

gf_log ("", GF_LOG_ERROR, "<------------------------------------End  ----------------------------------->");
}

/* Emd add */


//#endif
