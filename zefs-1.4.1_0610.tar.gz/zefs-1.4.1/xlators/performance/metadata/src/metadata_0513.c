/*
   Copyright (c) 2008-2012 Red Hat, Inc. <http://www.zecloud.cn>
   This file is part of ZeFS.

   This file is licensed to you under your choice of the GNU Lesser
   General Public License, version 3 or any later version (LGPLv3 or
   later), or the GNU General Public License, version 2 (GPLv2), in all
   cases as published by the Free Software Foundation.
*/
#ifndef _CONFIG_H
#define _CONFIG_H
#include "config.h"
#endif

//#if METADATA

#include "metadata.h"
#include "options.h"
#include "zefs3-xdr.h"
#include "syscall.h"
#include "syncop.h"
// cbk function

/* Add by hf@20150414 for metadata */
struct metadata_local;
typedef struct metadata_local metadata_local_t;

uint32_t
mtdata_hash_gfid (uuid_t gfid)
{
        uint32_t                hash = 0;
        uint64_t                msb64 = 0;
        uint64_t                lsb64 = 0;
        uint32_t                a1 = 0;
        uint32_t                a2 = 0;
        uint32_t                a3 = 0;
        uint32_t                a4 = 0;
        uint32_t                b1 = 0;
        uint32_t                b2 = 0;

        if (__is_root_gfid (gfid))
                return 0x1;

        memcpy (&msb64, &gfid[8], 8);
        memcpy (&lsb64, &gfid[0], 8);

        a1 = (msb64 << 32);
        a2 = (msb64 >> 32);
        a3 = (lsb64 << 32);
        a4 = (lsb64 >> 32);

        b1 = a1 ^ a4;
        b2 = a2 ^ a3;

        hash = b1 ^ b2;

        return hash;
}

uint64_t
mtdata_iatt_gfid_to_ino (struct iatt *buf)
{
        uint64_t ino  = 0;

        if (!buf)
                return 0;

        //if (gf_nfs_enable_ino32()) {
                ino = (uint32_t )mtdata_hash_gfid (buf->ia_gfid);
         //       goto hashout;
        //}

        /* from posix its guaranteed to send unique ino */
        //ino = buf->ia_ino;

//hashout:
        return ino;
}

metadata_local_t *
metadata_local_get (call_frame_t *frame)
{
        metadata_local_t *local = NULL;

        local = frame->local;
        if (local)
                goto out;

        local = GF_CALLOC (sizeof (*local), 1, gf_metadata_mt_private_t);
        if (!local)
                goto out;

        frame->local = local;
out:
        return local;
}

static int
_metadata_xattr_get_set (dict_t *xattr_req,
                      char *key,
                      data_t *data,
                      void *xattrargs)
{
gf_log ("", GF_LOG_INFO, "-----xattr get key=[%s], values=[%s]", 
							key, data->data);
        return 0;
}

dict_t *
metadata_lookup_xattr_get (xlator_t *this, loc_t *loc,
                         dict_t *xattr_req, struct iatt *buf)
{
        dict_t     				    *xattr    = NULL;
        metadata_xattr_filler_t      filler   = {0, };

        xattr = get_new_dict();
        if (!xattr) {
                goto out;
        }

        filler.this      = this;
        filler.xattr     = xattr;
        filler.stbuf     = buf;
        filler.loc       = loc;

        dict_foreach (xattr_req, _metadata_xattr_get_set, &filler);
out:
        return xattr;
}

/* metadata set virturl fd return directly */
static uint32_t      fd_value = 0;
uint32_t
metadata_fd_virt_set (xlator_t *this, loc_t *loc, fd_t *fd)
{
        uint32_t         ret = -1;
		uint32_t         nodepos;

		metadata_private_t       *priv = NULL;
		priv = this->private;
		nodepos = NODEHASHPOS(loc->gfid);
		fsnode *fsnd = NULL;

		if(fsnd){
			list_for_each_entry(fsnd, &priv->table->fsnodes_list[nodepos], fsnd_list){
				if (uuid_compare (fsnd->gfid, loc->gfid) == 0) {   //根据gfid定位fsnode，然后在遍历fsnode的扩展属性，赋值给dict
					if(!__is_root_gfid (loc->gfid))
						gf_log ("", GF_LOG_INFO, "1-find_next_fsdnode src_name=[%s], look_name=[%s] is the  same  ", 
							loc->name, fsnd->parents->name);
					ret = 0;
					fd_value++;
					fsnd->parents->d_fd = fd_value;
				}
			}
		}
#if 0
		while(fsnd){
			if (uuid_compare (fsnd->gfid, loc->gfid) == 0) {   //根据gfid定位fsnode，然后在遍历fsnode的扩展属性，赋值给dict
				if(!__is_root_gfid (loc->gfid))
					gf_log ("", GF_LOG_INFO, "1-find_next_fsdnode src_name=[%s], look_name=[%s] is the  same  ", loc->name, fsnd->parents->name);
				ret = 0;
				fd_value++;
				fsnd->d_fd = fd_value;
			break;
			}

			fsnd= fsnd->next;
		}
#endif
		gf_log ("", GF_LOG_INFO, "metadata_fd_virt_set fd_value=[%d]", fd_value);

		ret = fd_ctx_set (fd, this, (long)fd_value);
        if (ret)
                gf_log (this->name, GF_LOG_WARNING,
                        "failed to set the fd context path=%s fd=%p",
                        loc->path, fd);

        ret = 0;
		//fd->_ctx->value1 = fd_value;

        return ret;
}

#if 0
int
metadata_inode_xatt_get (xlator_t *this, loc_t *loc, dict_t *dict)
{
        int              ret = 0;
		uint32_t         nodepos;
		metadata_private_t         *priv ;
		priv = this->private;
		struct _xattr    *xattr = NULL;

		nodepos = NODEHASHPOS(loc->gfid);
		//fsnode *fsnd= priv->table->fsnodes_list[nodepos];
		fsnode *fsnd = NULL;

		while(fsnd){
			if (uuid_compare (fsnd->gfid, loc->gfid) == 0) {   //根据gfid定位fsnode，然后在遍历fsnode的扩展属性，赋值给dict
				if(!__is_root_gfid (loc->gfid))
					gf_log ("", GF_LOG_INFO, "1-find_next_fsdnode src_name=[%s], look_name=[%s] is the  same  ", loc->name, fsnd->parents->name);
				xattr = fsnd->xattr_array;

/*
               	ret = dict_set_dynptr (dict, xattr->key, xattr->value, strlen(xattr->value));
               	if (ret < 0) {
                    gf_log (this->name, GF_LOG_ERROR, "dict set operation "
                               "on %s for the key %s failed.", loc->path, xattr->key);
                    goto out;
				}
				gf_log ("", GF_LOG_INFO, "1-find_next_fsdnode key=[%s], value=[%s] ", xattr->key, xattr->value);
*/
//* 处理多个xattr  ,设置扩展属性 
				for(xattr=fsnd->xattr_array; xattr; xattr=xattr->next){
                	ret = dict_set_dynptr (dict, xattr->key, xattr->value, strlen(xattr->value));
                	if (ret < 0) {
                        gf_log (this->name, GF_LOG_ERROR, "dict set operation "
                                "on %s for the key %s failed.", loc->path, xattr->key);
                        goto out;
                	}
					gf_log ("", GF_LOG_INFO, "1-find_next_fsdnode key=[%s], value=[%s] ", xattr->key, xattr->value);
					//xattr = xattr->next;
				}

			
			break;
			}

			fsnd= fsnd->next;
		}
out:
        return ret;
}
#endif

static struct mtdata_key {
    const char *name;
    int         load;
    int         check;
} mtdata_keys[] = {
    {
        .name = "system.posix_acl_access",
        .load = 0,
        .check = 1,
    },
    {
        .name = "system.posix_acl_default",
        .load = 0,
        .check = 1,
    },
    {
        .name = "security.selinux",
        .load = 0,
        .check = 1,
    },
    {
        .name = "security.capability",
        .load = 0,
        .check = 1,
    },
    {
        .name = "gfid-req",
        .load = 0,
        .check = 1,
    },
        {
                .name = NULL,
                .load = 0,
                .check = 0,
        }
};

void
metadata_load_reqs (xlator_t *this, dict_t *dict)
{
    const char *mtdata_key = NULL;
    int  i = 0;
    int  ret = 0;

    for (mtdata_key = mtdata_keys[i].name; (mtdata_key = mtdata_keys[i].name); i++) {
        if (!mtdata_keys[i].load)
            continue;
        ret = dict_set_int8 (dict, (char *)mtdata_key, 0);
        if (ret)
            return;
    }
}

static int
is_metadata_key_satisfied (const char *key)
{
	const char *mtdata_key = NULL;
	int  i = 0;

	if (!key)
		return 0;

	for (mtdata_key = mtdata_keys[i].name; (mtdata_key = mtdata_keys[i].name); i++) {
		if (!mtdata_keys[i].load)
			continue;
		if (strcmp (mtdata_key, key) == 0)
			return 1;
	}

	return 0;
}

struct checkpair {
    int  ret;
    dict_t *rsp;
};

static int
metadata_checkfn (dict_t *this, char *key, data_t *value, void *data)
{
        struct checkpair *pair = data;

		if (!is_metadata_key_satisfied (key))
			pair->ret = 0;

        return 0;
}
int
metadata_xattr_satisfied (xlator_t *this, dict_t *req, dict_t *rsp)
{
        struct checkpair pair = {
                .ret = 1,
                .rsp = rsp,
        };

        dict_foreach (req, metadata_checkfn, &pair);

        return pair.ret;
}
#if 0
struct stat *
get_next_fsnode_stat(fsedge * fseg, loc_t *loc,  struct stat * fsnd_stat, char *lkname)
{
		while(fseg) {
				if(!strcmp(loc->name, fseg->name)){
					fsnd_stat = &fseg->child->stat;
        			uuid_copy (loc->gfid, fseg->child->gfid);
					if(fseg->child->linkname){
						gf_log ("", GF_LOG_INFO, "This is link file fseg->name=[%s], linkname=[%s] ", fseg->name, fseg->child->linkname);
						strcpy(lkname, fseg->child->linkname);
					}
					gf_log ("", GF_LOG_INFO, "2-fseg parent fsdnode=[%02x%02x] name=[%s]", fseg->child->gfid[14], fseg->child->gfid[15], fseg->name);
					break;
					}
				fseg = fseg->nextparent;
		}
		return fsnd_stat;
}
#endif

int
metadata_fsnode_lkname_get(xlator_t *this, loc_t *loc, char *lkname)
{
        int              ret = 0;
		//int              posnode = 0;
		struct    stat   *stat = NULL;
		metadata_private_t *priv  = NULL;
		fsnode           *fsnd = NULL;
		fsedge           *fseg = NULL;

		priv = this->private ;
		if(!uuid_is_null (loc->gfid)){
			//直接根据gfid找缓存中对应的fsnode 	
			fsnd = get_next_fsnode(priv->table,loc->gfid);
			if(fsnd)
				stat = &fsnd->stat;

			// For linkname 
			if(IA_ISLNK(ia_type_from_st_mode (stat->st_mode)) && 
					fsnd->parents->linkname ){
				strcpy(lkname, fsnd->parents->linkname);
			}
			
		}else if(uuid_is_null (loc->gfid) && 
			!uuid_is_null (loc->pargfid)){
			//如果loc->pargfid为空，则需要根据 pargfid+name到缓存中找 	
			fseg = get_next_fsedge(priv->table, loc->pargfid, loc->name);
			if(fseg->linkname){
				gf_log ("", GF_LOG_INFO, "This is link file fseg->name=[%s], linkname=[%s] ", fseg->name, fseg->linkname);
				strcpy(lkname, fseg->linkname);
			}
		}else{
			gf_log (this->name, GF_LOG_INFO, "gfid and pargfid is null ");

		}

		return ret;
}

int
metadata_parinode_iatt_get (metadata_private_t *priv, uuid_t gfid, struct iatt *iatt)
{
        int              ret = -1;
		struct    stat   *stat = NULL;
		fsedge           *fseg = NULL;

        if (uuid_is_null (gfid)) { 
                gf_log (this->name, GF_LOG_ERROR,
                        "null gfid for path %s", loc->path); 
			goto out;
        } 

		if(!uuid_is_null (loc->pargfid)){
			fseg = get_next_fsedge(priv->table, loc->pargfid, loc->name);
			if(fseg){
				stat = &fseg->parent->stat;
       			uuid_copy (iatt->ia_gfid, fseg->parent->gfid);
			}
		}else{
			gf_log (THIS->name, GF_LOG_INFO, "pargfid is null ");
			goto out;
		}

		if(!stat){
			gf_log (THIS->name, GF_LOG_INFO, "Not found this fsnode,loc->name=[%s] gfid and pargfid is null ", loc->name);
			goto out;
		}

        LOCK (&priv->table->lock);
        {
                iatt_from_stat(iatt, stat );
        }
        UNLOCK (&priv->table->lock);

		ret = 0;
out:
		return ret;
}
int
metadata_inode_iatt_get (metadata_private_t *priv, loc_t *loc, struct iatt *iatt)
{
        uint32_t         ret = 0;
		struct    stat   *stat = NULL;
		//metadata_private_t *priv  = NULL;
		fsnode           *fsnd = NULL;
		fsedge           *fseg = NULL;

		//priv = this->private ;

gf_log ("", GF_LOG_INFO, "00-metadata lookup loc->gfid=[%02x%02x%02x%02x], loc->pargfid=[%02x%02x%02x%02x]",   
			loc->gfid[12], loc->gfid[13],loc->gfid[14], loc->gfid[15], 
			loc->pargfid[12], loc->pargfid[13],loc->pargfid[14], loc->pargfid[15]);
		
#if DEBUF
//存在问题， 如果多个fsnode存在一个hash_table对应的索引位置 
#endif
        if (uuid_is_null (loc->pargfid) || !loc->name) { 
                gf_log (THIS->name, GF_LOG_ERROR,
                        "null pargfid/name for path %s", loc->path);
				ret = -1;
                goto out;
        }

		if(!uuid_is_null (loc->gfid)){
			//直接根据gfid找缓存中对应的fsnode 	
			fsnd = get_next_fsnode(priv->table,loc->gfid);
			if(fsnd){
				stat = &fsnd->stat;
        		uuid_copy (iatt->ia_gfid, loc->gfid);
			}else {
				ret = -1;
				goto out;
			}
		}else if(!uuid_is_null (loc->pargfid)){
			//如果loc->pargfid为空，则需要根据 pargfid+name到缓存中找 	
			fseg = get_next_fsedge(priv->table,loc->pargfid, loc->name);
			if(fseg){
				gf_log ("", GF_LOG_INFO, "2-fseg parent fsdnode=[%02x%02x] name=[%s]", fseg->child->gfid[14], fseg->child->gfid[15], fseg->name);
				stat = &fseg->child->stat;
        		uuid_copy (iatt->ia_gfid, fseg->child->gfid);
			}else {
				ret = -1;
				goto out;
			}
		}else{
			gf_log (THIS->name, GF_LOG_INFO, "gfid and pargfid is null ");
			ret = -1;
			goto out;
		}

		if(!stat){
			gf_log (THIS->name, GF_LOG_INFO, "Not found this fsnode,loc->name=[%s] gfid and pargfid is null ", loc->name);
        	ret = -1;
			goto out;
		}

        LOCK (&priv->table->lock);
        {
            iatt_from_stat(iatt, stat );
        }
        UNLOCK (&priv->table->lock);

        //uuid_copy (iatt->ia_gfid, loc->gfid);
/*
        iatt->ia_ino    = gfid_to_ino (inode->gfid);
        iatt->ia_dev    = 42;
        iatt->ia_type   = inode->ia_type;
*/

out:
        return ret;
}


void
metadata_local_wipe (xlator_t *this, metadata_private_t *local)
{
        if (!local)
                return;

/*
        loc_wipe (&local->loc);

        loc_wipe (&local->loc2);

        if (local->fd)
                fd_unref (local->fd);

        GF_FREE (local->linkname);

        GF_FREE (local->key);

        if (local->xattr)
                dict_unref (local->xattr);
*/

        GF_FREE (local);
        return;
}
#define MTDATA_STACK_UNWIND(fop, frame, params ...) do {           \
                metadata_private_t  *__local = NULL;                    \
                xlator_t    *__xl    = NULL;                    \
                if (frame) {                                    \
                        __xl         = frame->this;             \
                        __local      = frame->local;            \
                        frame->local = NULL;                    \
                }                                               \
                STACK_UNWIND_STRICT (fop, frame, params);       \
                metadata_local_wipe (__xl, __local);                 \
        } while (0)

/* End add */

static int
metadata_xattr_get (dict_t *xattr_req,
                      char *key,
                      data_t *data,
                      void *xattrargs)
{
    //gf_log ("", GF_LOG_ERROR, "xattr=[%p], key=[%s], value=[%s]", &xattr_req, key, data->data);
    if(!xattr_req){
        gf_log ("", GF_LOG_ERROR, "key=[%s], value=[%s]", key, data->data);
    }
    return 0;
}

int32_t
metadata_lookup_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno, inode_t *inode,
                    struct iatt *buf, dict_t *xdata, struct iatt *postparent)
{
		int a = 0;
        dict_t     *xattr             = NULL;

        xattr = get_new_dict();
        if (!xattr) {
                goto out;
        }
/*
	if(xdata->members_list)
    	gf_log ("", GF_LOG_ERROR, "xattr=[%p] refcount=[%s]", &xdata, xdata->members_list->key);
*/
		a = dict_foreach (xdata, metadata_xattr_get, xattr);
    	gf_log ("", GF_LOG_ERROR, "xattr=[%p]", &xdata);
        metadata_private_t *local = NULL;

gf_log ("", GF_LOG_ERROR, "metadata_lookup_cbk() buf->gfid=[%02x%02x], postparent->gfid=[%02x%02x] inode->gfid=[%02x%02x]", 
			buf->ia_gfid[14],buf->ia_gfid[15], postparent->ia_gfid[14],postparent->ia_gfid[15],
			inode->gfid[14], inode->gfid[15]);
		local = frame->local;

        if (op_ret != 0)
                goto out;

        if (!local)
                goto out;

/*
        if (local->loc.parent) {
                metadata_inode_iatt_set (this, local->loc.parent, postparent);
        }

        if (local->loc.inode) {
                metatdata_inode_iatt_set (this, local->loc.inode, stbuf);
                metatdata_inode_xatt_set (this, local->loc.inode, xdata);
        }
*/
out:
/*
        MDC_STACK_UNWIND (lookup, frame, op_ret, op_errno, inode, stbuf,
                          dict, postparent);
*/
		//加载完成

		MTDATA_STACK_UNWIND(lookup, frame, op_ret, op_errno, inode, buf,
                         xdata, postparent);
/*
        STACK_UNWIND_STRICT (lookup, frame, op_ret, op_errno, inode, buf,
                             xdata, postparent);
*/
        return 0;
}

int32_t
metadata_stat_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                  int32_t op_ret, int32_t op_errno, struct iatt *buf,
                  dict_t *xdata)
{
        STACK_UNWIND_STRICT (stat, frame, op_ret, op_errno, buf, xdata);
        return 0;
}


int32_t
metadata_truncate_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno, struct iatt *prebuf,
                      struct iatt *postbuf,
                      dict_t *xdata)
{
        STACK_UNWIND_STRICT (truncate, frame, op_ret, op_errno, prebuf,
                             postbuf, xdata);
        return 0;
}

int32_t
metadata_ftruncate_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                       int32_t op_ret, int32_t op_errno, struct iatt *prebuf,
                       struct iatt *postbuf,
                       dict_t *xdata)
{
        STACK_UNWIND_STRICT (ftruncate, frame, op_ret, op_errno, prebuf,
                             postbuf, xdata);
        return 0;
}

int32_t
metadata_access_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno,
                    dict_t *xdata)
{
        STACK_UNWIND_STRICT (access, frame, op_ret, op_errno, xdata);
        return 0;
}

int32_t
metadata_readlink_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno, const char *path,
                      struct iatt *buf, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_readlink_cbk path=[%s]",path);

        STACK_UNWIND_STRICT (readlink, frame, op_ret, op_errno, path, buf,
                             xdata);
        return 0;
}


int32_t
metadata_mknod_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno, inode_t *inode,
                   struct iatt *buf, struct iatt *preparent,
                   struct iatt *postparent, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_mkmod_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (mknod, frame, op_ret, op_errno, inode,
                             buf, preparent, postparent, xdata);
        return 0;
}

int32_t
metadata_mkdir_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno, inode_t *inode,
                   struct iatt *buf, struct iatt *preparent,
                   struct iatt *postparent, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_mkdir_cbk buf->gfid=[%02x%02x], preparent->gfid=[%02x%02x]", 
				buf->ia_gfid[14], buf->ia_gfid[15],
				preparent->ia_gfid[14], preparent->ia_gfid[15]);

		metadata_private_t     *priv      = NULL;
		fsnode                 *fsnd      = NULL;
		//fsedge                 *fseg      = NULL;
		fsnode                 *newfsnode = NULL;
		fsedge                 *newfsedge = NULL;
		int32_t                 posnode   = 0;
        metadata_local_t       *local     = NULL;
		struct dirent          *entry     = NULL;
		
        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (this->private, uncached);

        local = frame->local;

        if (op_ret != 0)
                goto uncached;

        if (!local)
                goto uncached;

		priv = this->private;

		fsnd = get_next_fsnode(priv->table, preparent->ia_gfid);
		if(!fsnd){
			gf_log (this->name, GF_LOG_ERROR, "metadata_symlink_cbk uncached fali!");
			goto uncached;
		}
		//fseg = get_next_fsedge(priv->table, preparent->ia_gfid, local->loc.name);

        entry = GF_CALLOC (1, sizeof(struct dirent), 
                               gf_common_mt_gf_dirent_t);

		entry->d_ino = mtdata_iatt_gfid_to_ino (buf);
		entry->d_off = entry->d_ino;   //文件偏移量off在metadata层，暂时无用，只要不是空，就可以遍历成功。
		entry->d_reclen = strlen(local->loc.name);
		entry->d_type = buf->ia_type;
		strcpy(entry->d_name , local->loc.name);


gf_log ("", GF_LOG_INFO, "Readir this  entry->d_off=[%ld]", entry->d_off);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_ino=[%ld]", entry->d_ino);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_type=[%d]", entry->d_type);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_reclen=[%d]", entry->d_reclen);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_name =[%s]", entry->d_name);

		
		newfsnode = fsnodes_node_add(buf);
		newfsedge = fsedges_edge_add(entry,  fsnd, newfsnode, NULL);

		if(newfsedge){
			gf_log (this->name, GF_LOG_INFO, "Last fseg parent posnode=[%d],fsdnode=[%02x%02x] name=[%s]",
					posnode, newfsedge->child->gfid[14], newfsedge->child->gfid[15], newfsedge->name);
		}else{
			//元数据缓存失败 怎么处理?  磁盘写入成功
			gf_log (this->name, GF_LOG_INFO, "metadata_mkdir_cbk uncached fali!");
			op_ret = -1;
			goto uncached;
		}

		add_fsnode_to_hash_table(preparent->ia_gfid, newfsnode, newfsedge, priv->table);

uncached:
		if(entry){
			GF_FREE(entry);
		}

        MTDATA_STACK_UNWIND(mkdir, frame, op_ret, op_errno, inode,
                             buf, preparent, postparent, xdata);
        return 0;
}

int32_t
metadata_unlink_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno, struct iatt *preparent,
                    struct iatt *postparent, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_unlink_cbk  op_ret=[%d], postparent->gfid=[%02x%02x], linknumber=[%d]",
                op_ret, postparent->ia_gfid[14], postparent->ia_gfid[15], postparent->ia_nlink);

        metadata_private_t     *priv      = NULL;
        fsedge                 *fseg      = NULL;
        metadata_local_t       *local     = NULL;
		int32_t                 d_type    = 0;
		struct iatt             stbuf     = {0, };

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (this->private, uncached);

        local = frame->local;
        if (op_ret != 0)
                goto uncached;

        if (!local)
                goto uncached;

        priv = this->private;

        fseg = get_next_fsedge(priv->table, preparent->ia_gfid, local->loc.name);
        if(!fseg){
            gf_log (this->name, GF_LOG_DEBUG, "metadata_unlink_cbk not find this fsedge name=[%s]",
                local->loc.name);
            goto uncached;
        }
		
		//for hard link 当删除一个硬链接时，需要更新其他硬链接对应的stat
		d_type = ia_type_from_st_mode (fseg->child->stat.st_mode);

	    iatt_from_stat (&stbuf, &fseg->child->stat);
		
        gf_log (this->name, GF_LOG_INFO, "metadata_unlink_cbk hard link file linknumber =[%ld],d_type=[%d]",
				fseg->child->stat.st_nlink , d_type);

		//更新父目录的状态信息 有待优化？  ctime更新有问题。
		fsnodes_node_upd(fseg->parent, preparent, 0); 

		if (IA_ISREG (d_type)){
			stbuf.ia_nlink--;
			fsnodes_node_upd(fseg->child, &stbuf, 1); 
			if(1 == fseg->child->stat.st_nlink){ //硬链接文件数剩最后一个，再删除则需要删除fsnode+fsedge
        		fsnodes_node_del(priv->table, fseg->child->gfid, local->loc.inode->ia_type);
        		fsnodes_edge_del(priv->table, preparent->ia_gfid, local->loc.name);
			}
        	fsnodes_edge_del(priv->table, preparent->ia_gfid, local->loc.name);
		}else{
        	fsnodes_node_del(priv->table, fseg->child->gfid, local->loc.inode->ia_type);
        	fsnodes_edge_del(priv->table, preparent->ia_gfid, local->loc.name);
		}


uncached:

        MTDATA_STACK_UNWIND (unlink, frame, op_ret, op_errno, preparent,
                             postparent, xdata);
        return 0;
}

int32_t
metadata_rmdir_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno, struct iatt *preparent,
                   struct iatt *postparent,
                   dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_rmdir_cbk  op_ret=[%d], preparent->gfid=[%02x%02x]",
                op_ret, preparent->ia_gfid[14], preparent->ia_gfid[15]);

        metadata_private_t     *priv      = NULL;
        fsedge                 *fseg      = NULL;
        metadata_local_t       *local     = NULL;

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (this->private, uncached);

        local = frame->local;

        if (op_ret != 0)
                goto uncached;

        if (!local)
                goto uncached;

        priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

        fseg = get_next_fsedge(priv->table, preparent->ia_gfid, local->loc.name);
        if(!fseg){
            gf_log (this->name, GF_LOG_DEBUG, "metadata_unlink_cbk not find this fsedge name=[%s]",
                local->loc.name);
            goto uncached;
        }

        fsnodes_node_del(priv->table, fseg->child->gfid, local->loc.inode->ia_type);
        fsnodes_edge_del(priv->table, preparent->ia_gfid, local->loc.name);

uncached:
        MTDATA_STACK_UNWIND (rmdir, frame, op_ret, op_errno, preparent,
                             postparent, xdata);
        return 0;
}


int32_t
metadata_symlink_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno, inode_t *inode,
                     struct iatt *buf, struct iatt *preparent,
                     struct iatt *postparent, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_symlink_cbk op_ret=[%d]", op_ret);
// 需要更新缓存中对应扩展属性，在xdata中。
gf_log (this->name, GF_LOG_INFO, "metadata_symlink_cbk buf->gfid=[%02x%02x%02x%02x], preparent->gfid=[%02x%02x%02x%02x]", 
				buf->ia_gfid[12], buf->ia_gfid[13],buf->ia_gfid[14], buf->ia_gfid[15],
				preparent->ia_gfid[12], preparent->ia_gfid[13],preparent->ia_gfid[14], preparent->ia_gfid[15]);

		metadata_private_t     *priv      = NULL;
		fsnode                 *fsnd      = NULL;
		//fsedge                 *fseg      = NULL;
		fsnode                 *newfsnode = NULL;
		fsedge                 *newfsedge = NULL;
		int32_t                 posnode   = 0;
        metadata_local_t       *local     = NULL;
		struct dirent          *entry     = NULL;
		
        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (this->private, uncached);

        local = frame->local;

        if (op_ret != 0)
                goto uncached;

        if (!local)
                goto uncached;

		priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		fsnd = get_next_fsnode(priv->table, preparent->ia_gfid);
		if(!fsnd){
			gf_log (this->name, GF_LOG_ERROR, "metadata_symlink_cbk uncached fali!");
			goto uncached;
		}
		//fseg = get_next_fsedge(priv->table, preparent->ia_gfid, local->loc.name);

        entry = GF_CALLOC (1, sizeof(*entry),
                               gf_common_mt_gf_dirent_t);

		entry->d_ino = mtdata_iatt_gfid_to_ino (buf);
		entry->d_off = entry->d_ino;   //文件偏移量off在metadata层，暂时无用，只要保证d_off唯一，就可以遍历成功。
		entry->d_reclen = strlen(local->loc.name);
		entry->d_type = buf->ia_type;
		strcpy(entry->d_name , local->loc.name);

		newfsnode = fsnodes_node_add(buf);
		newfsedge = fsedges_edge_add(entry,  fsnd, newfsnode, local->linkname);

		if(newfsedge){
			gf_log (this->name, GF_LOG_INFO, "Last fseg parent posnode=[%d],fsdnode=[%02x%02x] name=[%s]",
					posnode, newfsedge->child->gfid[14], newfsedge->child->gfid[15], newfsedge->name);
		}else{
			//元数据缓存失败 怎么处理?  磁盘写入成功
			gf_log (this->name, GF_LOG_ERROR, "metadata_symlink_cbk uncached fali!");
			goto uncached;
		}

		add_fsnode_to_hash_table(preparent->ia_gfid, newfsnode, newfsedge, priv->table);

uncached:
		if(entry){
			GF_FREE(entry);
		}

        MTDATA_STACK_UNWIND (symlink, frame, op_ret, op_errno, inode, buf,
                             preparent, postparent, xdata);
        return 0;
}


int32_t
metadata_rename_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno, struct iatt *buf,
                    struct iatt *preoldparent, struct iatt *postoldparent,
                    struct iatt *prenewparent, struct iatt *postnewparent,
                    dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_rename_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (rename, frame, op_ret, op_errno, buf, preoldparent,
                             postoldparent, prenewparent, postnewparent, xdata);
        return 0;
}


int32_t
metadata_link_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                  int32_t op_ret, int32_t op_errno, inode_t *inode,
                  struct iatt *buf, struct iatt *preparent,
                  struct iatt *postparent,
                  dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_link_cbk  op_ret=[%d], linknumber=[%d]", op_ret, buf->ia_nlink);
gf_log (this->name, GF_LOG_INFO, "metadata_link_cbk buf->gfid=[%02x%02x%02x%02x], preparent->gfid=[%02x%02x%02x%02x]", 
				buf->ia_gfid[12], buf->ia_gfid[13],buf->ia_gfid[14], buf->ia_gfid[15],
				preparent->ia_gfid[12], preparent->ia_gfid[13],preparent->ia_gfid[14], preparent->ia_gfid[15]);

		metadata_private_t     *priv      = NULL;
		fsnode                 *srcfsnd   = NULL;
		fsedge                 *srcfseg   = NULL;
		fsnode                 *parfsnode = NULL;
		fsedge                 *parfsedge = NULL;
		fsedge                 *newfsedge = NULL;
		int32_t                 posnode   = 0;
        metadata_local_t       *local     = NULL;
		struct dirent          *entry     = NULL;
		
        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (this->private, uncached);

        local = frame->local;

        if (op_ret != 0)
                goto uncached;

        if (!local)
                goto uncached;

		priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

/* 找到硬链接源文件 在缓存中的fsnode  硬链接时只需要hashtable中fsedge */
gf_log (this->name, GF_LOG_INFO, "metadata_link_cbk loc->path=[%s], loc->name[%s], loc->gfid=[%02x%02x]",
					local->loc.path, local->loc.name, local->loc.gfid[14], local->loc.gfid[15]);

		if(!uuid_is_null (local->loc.gfid)){
			srcfsnd = get_next_fsnode(priv->table, local->loc.gfid);
			if(srcfsnd){
				srcfseg = srcfsnd->parents;
			}else{
				gf_log (this->name, GF_LOG_INFO, "metadata_create_cbk uncached fali!");
				op_ret = -1;
				goto uncached;
			}
		}else{
			srcfseg = get_next_fsedge(priv->table, local->loc.pargfid, local->loc.name);
			if(srcfseg)
				srcfsnd = srcfseg->child;
		}
/* 查找硬链接文件所在新的目录对应的父目录的fsnode */
gf_log (this->name, GF_LOG_INFO, "metadata_link_cbk loc2->path=[%s],loc2->name=[%s],loc2->gfid=[%02x%02x]",
					local->loc2.path, local->loc2.name, local->loc2.gfid[14], local->loc2.gfid[15]);
		if(!uuid_is_null (preparent->ia_gfid)){
			parfsnode = get_next_fsnode(priv->table, preparent->ia_gfid);
			if(parfsnode){
				parfsedge = parfsnode->parents;
			}else{
				gf_log (this->name, GF_LOG_INFO, "metadata_create_cbk uncached fali!");
				op_ret = -1;
				goto uncached;
			}
		}
gf_log (this->name, GF_LOG_INFO, "metadata_link_cbk srcfsnd->name=[%s], parfsedge->name=[%s]",
					srcfsnd->parents->name, parfsedge->name);

        entry = GF_CALLOC (1, sizeof(*entry),
                               gf_common_mt_gf_dirent_t);

		entry->d_ino = mtdata_iatt_gfid_to_ino (buf);
		entry->d_off = entry->d_ino;   //文件偏移量off在metadata层，暂时无用，只要保证d_off唯一，就可以遍历成功。
		entry->d_reclen = strlen(local->loc2.name);
		entry->d_type = buf->ia_type;
		strcpy(entry->d_name , local->loc2.name);

		//硬链接文件对应源文件对应的所有连接文件都要更新的属性和状态 
		fsnodes_node_upd(srcfsnd , buf, 1);
		fsnodes_node_upd(srcfseg->parent , preparent, 0);
gf_log (this->name, GF_LOG_INFO, "metadata_link_cbk parfsnode->gfid=[%02x%02x],name=[%s] +++++  srcfsnd->gfid=[%02x%02x], name=[%s]",
					parfsnode->gfid[14],parfsnode->gfid[15],parfsnode->parents->name,
					 srcfsnd->gfid[14], srcfsnd->gfid[15], srcfsnd->parents->name);

		newfsedge = fsedges_edge_add(entry, parfsnode, srcfsnd, local->loc.path);

		if(newfsedge){
			gf_log (this->name, GF_LOG_INFO, "Last fseg parent posnode=[%d],fsdnode=[%02x%02x] name=[%s]",
					posnode, newfsedge->child->gfid[14], newfsedge->child->gfid[15], newfsedge->name);
		}else{
			//元数据缓存失败 怎么处理?  磁盘写入成功
			gf_log (this->name, GF_LOG_INFO, "metadata_create_cbk uncached fali!");
			op_ret = -1;
			goto uncached;
		}

		add_fsnode_to_hash_table(preparent->ia_gfid, NULL, newfsedge, priv->table);

uncached:
		if(entry){
			GF_FREE(entry);
		}

        MTDATA_STACK_UNWIND (link, frame, op_ret, op_errno, inode, buf,
                             preparent, postparent, xdata);
        return 0;
}

int32_t
metadata_create_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno, fd_t *fd, inode_t *inode,
                    struct iatt *buf, struct iatt *preparent,
                    struct iatt *postparent,
                    dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_create_cbk  op_ret=[%d]", op_ret);
gf_log (this->name, GF_LOG_INFO, "metadata_create_cbk buf->gfid=[%02x%02x%02x%02x], preparent->gfid=[%02x%02x%02x%02x]", 
				buf->ia_gfid[12], buf->ia_gfid[13],buf->ia_gfid[14], buf->ia_gfid[15],
				preparent->ia_gfid[12], preparent->ia_gfid[13],preparent->ia_gfid[14], preparent->ia_gfid[15]);

		metadata_private_t     *priv      = NULL;
		fsnode                 *fsnd      = NULL;
		//fsedge                 *fseg      = NULL;
		fsnode                 *newfsnode = NULL;
		fsedge                 *newfsedge = NULL;
		int32_t                 posnode   = 0;
        metadata_local_t       *local     = NULL;
		struct dirent          *entry     = NULL;
		
        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (this->private, uncached);
        VALIDATE_OR_GOTO (fd, uncached);

        local = frame->local;

        if (op_ret != 0)
                goto uncached;

        if (!local)
                goto uncached;

		priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		fsnd = get_next_fsnode(priv->table, preparent->ia_gfid);
		if(!fsnd){
			gf_log (this->name, GF_LOG_ERROR, "metadata_symlink_cbk uncached fali!");
			goto uncached;
		}
		//fseg = get_next_fsedge(priv->table, preparent->ia_gfid, local->loc.name);

        entry = GF_CALLOC (1, sizeof(*entry),
                               gf_common_mt_gf_dirent_t);

		entry->d_ino = mtdata_iatt_gfid_to_ino (buf);
		entry->d_off = entry->d_ino;   //文件偏移量off在metadata层，暂时无用，只要保证d_off唯一，就可以遍历成功。
		entry->d_reclen = strlen(local->loc.name);
		entry->d_type = buf->ia_type;
		strcpy(entry->d_name , local->loc.name);

/*
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_off=[%ld]", entry->d_off);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_ino=[%ld]", entry->d_ino);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_type=[%d]", entry->d_type);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_reclen=[%d]", entry->d_reclen);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_name =[%s]", entry->d_name);
*/
		
		newfsnode = fsnodes_node_add(buf);
		newfsedge = fsedges_edge_add(entry, fsnd, newfsnode, NULL);

		if(newfsedge){
			gf_log (this->name, GF_LOG_INFO, "Last fseg parent posnode=[%d],fsdnode=[%02x%02x] name=[%s]",
					posnode, newfsedge->child->gfid[14], newfsedge->child->gfid[15], newfsedge->name);
		}else{
			//元数据缓存失败 怎么处理?  磁盘写入成功
			gf_log (this->name, GF_LOG_INFO, "metadata_create_cbk uncached fali!");
			op_ret = -1;
			goto uncached;
		}

		add_fsnode_to_hash_table(preparent->ia_gfid, newfsnode, newfsedge, priv->table);

uncached:
		if(entry){
			GF_FREE(entry);
		}
        MTDATA_STACK_UNWIND(create, frame, op_ret, op_errno, fd, inode, buf,
                             preparent, postparent, xdata);
        return 0;
}

int32_t
metadata_open_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                  int32_t op_ret, int32_t op_errno, fd_t *fd,
                  dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_open_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (open, frame, op_ret, op_errno, fd, xdata);
        return 0;
}

int32_t
metadata_readv_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno, struct iovec *vector,
                   int32_t count, struct iatt *stbuf, struct iobref *iobref,
                   dict_t *xdata)
{
        STACK_UNWIND_STRICT (readv, frame, op_ret, op_errno, vector, count,
                             stbuf, iobref, xdata);
        return 0;
}


int32_t
metadata_writev_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno, struct iatt *prebuf,
                    struct iatt *postbuf,
                    dict_t *xdata)
{
        STACK_UNWIND_STRICT (writev, frame, op_ret, op_errno, prebuf, postbuf, xdata);
        return 0;
}


int32_t
metadata_flush_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno,
                   dict_t *xdata)
{
        STACK_UNWIND_STRICT (flush, frame, op_ret, op_errno, xdata);
        return 0;
}



int32_t
metadata_fsync_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno, struct iatt *prebuf,
                   struct iatt *postbuf,
                   dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fsync_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fsync, frame, op_ret, op_errno, prebuf, postbuf,
                             xdata);
        return 0;
}

int32_t
metadata_fstat_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                   int32_t op_ret, int32_t op_errno, struct iatt *buf,
                   dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fstat_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fstat, frame, op_ret, op_errno, buf, xdata);
        return 0;
}

int32_t
metadata_opendir_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno, fd_t *fd,
                     dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_opendir_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (opendir, frame, op_ret, op_errno, fd, xdata);
        return 0;
}

int32_t
metadata_fsyncdir_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno,
                      dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fsyncdir_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fsyncdir, frame, op_ret, op_errno, xdata);
        return 0;
}

int32_t
metadata_statfs_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                    int32_t op_ret, int32_t op_errno, struct statvfs *buf,
                    dict_t *xdata)
{
        STACK_UNWIND_STRICT (statfs, frame, op_ret, op_errno, buf, xdata);
        return 0;
}


int32_t
metadata_setxattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno,
                      dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_setxattr_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (setxattr, frame, op_ret, op_errno, xdata);
        return 0;
}


int32_t
metadata_fsetxattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                       int32_t op_ret, int32_t op_errno,
                       dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fsetxattr_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fsetxattr, frame, op_ret, op_errno, xdata);
        return 0;
}



int32_t
metadata_fgetxattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                       int32_t op_ret, int32_t op_errno, dict_t *dict,
                       dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fgetxattr_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fgetxattr, frame, op_ret, op_errno, dict, xdata);
        return 0;
}


int32_t
metadata_getxattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno, dict_t *dict,
                      dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_getxattr_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (getxattr, frame, op_ret, op_errno, dict, xdata);
        return 0;
}

int32_t
metadata_xattrop_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno, dict_t *dict,
                     dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_xattrop_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (xattrop, frame, op_ret, op_errno, dict, xdata);
        return 0;
}

int32_t
metadata_fxattrop_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno, dict_t *dict,
                      dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fxattrop_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fxattrop, frame, op_ret, op_errno, dict, xdata);
        return 0;
}


int32_t
metadata_removexattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                         int32_t op_ret, int32_t op_errno,
                         dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_removexattr_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (removexattr, frame, op_ret, op_errno, xdata);
        return 0;
}


int32_t
metadata_fremovexattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                          int32_t op_ret, int32_t op_errno,
                          dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fremovexattr_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fremovexattr, frame, op_ret, op_errno, xdata);
        return 0;
}

int32_t
metadata_lk_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                int32_t op_ret, int32_t op_errno, struct gf_flock *lock,
                dict_t *xdata)
{
        STACK_UNWIND_STRICT (lk, frame, op_ret, op_errno, lock, xdata);
        return 0;
}

int32_t
metadata_inodelk_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno,
                     dict_t *xdata)
{
        STACK_UNWIND_STRICT (inodelk, frame, op_ret, op_errno, xdata);
        return 0;
}


int32_t
metadata_finodelk_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno,
                      dict_t *xdata)
{
        STACK_UNWIND_STRICT (finodelk, frame, op_ret, op_errno, xdata);
        return 0;
}

int32_t
metadata_entrylk_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno,
                     dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_entrylk_cbk  op_ret=[%d]", op_ret);
        STACK_UNWIND_STRICT (entrylk, frame, op_ret, op_errno, xdata);
        return 0;
}

int32_t
metadata_fentrylk_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno,
                      dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fentrylk_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (fentrylk, frame, op_ret, op_errno, xdata);
        return 0;
}


int32_t
metadata_rchecksum_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                       int32_t op_ret, int32_t op_errno, uint32_t weak_checksum,
                       uint8_t *strong_checksum,
                       dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_rchecksum_cbk  op_ret=[%d]", op_ret);

        STACK_UNWIND_STRICT (rchecksum, frame, op_ret, op_errno, weak_checksum,
                             strong_checksum, xdata);
        return 0;
}


int32_t
metadata_readdir_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno, gf_dirent_t *entries,
                     dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata readdir_cbk  op_ret=[%d]", op_ret);
        STACK_UNWIND_STRICT (readdir, frame, op_ret, op_errno, entries, xdata);
        return 0;
}


int32_t
metadata_readdirp_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno, gf_dirent_t *entries,
                      dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata readdirp_cbk  op_ret=[%d]", op_ret);
        STACK_UNWIND_STRICT (readdirp, frame, op_ret, op_errno, entries, xdata);
        return 0;
}

int32_t
metadata_setattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno, struct iatt *statpre,
                     struct iatt *statpost,
                     dict_t *xdata)
{
        STACK_UNWIND_STRICT (setattr, frame, op_ret, op_errno, statpre,
                             statpost, xdata);
        return 0;
}

int32_t
metadata_fsetattr_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                      int32_t op_ret, int32_t op_errno, struct iatt *statpre,
                      struct iatt *statpost,
                      dict_t *xdata)
{
        STACK_UNWIND_STRICT (fsetattr, frame, op_ret, op_errno, statpre,
                             statpost, xdata);
        return 0;
}

int32_t
metadata_getspec_cbk (call_frame_t *frame, void *cookie, xlator_t *this,
                     int32_t op_ret, int32_t op_errno, char *spec_data)
{
        STACK_UNWIND_STRICT (getspec, frame, op_ret, op_errno, spec_data);
        return 0;
}

// stack_wind function
int32_t
metadata_fgetxattr (call_frame_t *frame, xlator_t *this, fd_t *fd,
                          const char *name, dict_t *xdata)
{
        STACK_WIND (frame, metadata_fgetxattr_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fgetxattr, fd, name, xdata);
        return 0;
}

int32_t
metadata_fsetxattr (call_frame_t *frame, xlator_t *this, fd_t *fd,
                          dict_t *dict, int32_t flags, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata fsetxattr ");

        STACK_WIND (frame, metadata_fsetxattr_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fsetxattr, fd, dict, flags, xdata);
        return 0;
}

int32_t
metadata_setxattr (call_frame_t *frame, xlator_t *this, loc_t *loc,
                         dict_t *dict, int32_t flags, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata setxattr loc->path =[%s]", loc->path);

        STACK_WIND (frame, metadata_setxattr_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->setxattr, loc, dict, flags, xdata);
        return 0;
}

int32_t
metadata_statfs (call_frame_t *frame, xlator_t *this, loc_t *loc, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata statfs loc->path =[%s]", loc->path);

        STACK_WIND (frame, metadata_statfs_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->statfs, loc, xdata);
        return 0;
}

int32_t
metadata_fsyncdir (call_frame_t *frame, xlator_t *this, fd_t *fd,
                         int32_t flags, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata fsyncdir flags =[%d]", flags);

        STACK_WIND (frame, metadata_fsyncdir_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fsyncdir, fd, flags, xdata);
        return 0;
}

int32_t
metadata_opendir (call_frame_t *frame, xlator_t *this, loc_t *loc,
                        fd_t *fd, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata opendir loc->path=[%s], fd->pid=[%ld], fd->value=[%ld], fd->inode->gfid=[%s]",
				loc->path, fd->pid, fd->_ctx->value1, uuid_utoa(fd->inode->gfid));
		int32_t               op_ret   = -1;
		int32_t               op_errno = 0;
		//struct  mtdata_fd    *pfd      = NULL;
        metadata_private_t   *priv     = NULL;

		//DECLARE_OLD_FS_ID_VAR;

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
		VALIDATE_OR_GOTO (loc, uncached);
		VALIDATE_OR_GOTO (loc->path, uncached);
        VALIDATE_OR_GOTO (fd, uncached);

        //SET_FS_ID (frame->root->uid, frame->root->gid);

        priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

		op_ret = metadata_fd_virt_set(this, loc, fd);
		if(op_ret < 0){
			gf_log ("", GF_LOG_INFO, "metadata cached not found  loc->path=[%s]", loc->path);
			goto uncached;
		}
			
		
/*
        op_ret = metadata_fd_ctx_get (fd, this, &pfd);
        if (op_ret < 0) {
                gf_log (this->name, GF_LOG_WARNING,
                        "pfd is NULL, fd=%p", fd);
                op_errno = -op_ret;
                goto uncached;
        }		
*/

        //SET_TO_OLD_FS_ID ();
gf_log (this->name, GF_LOG_INFO, "++Begin metadata opendir loc->path=[%s], fd->pid=[%ld],fd->value=[%ld]",loc->path, fd->pid, fd->_ctx->value1);
        MTDATA_STACK_UNWIND(opendir, frame, op_ret, op_errno, fd, NULL);
        return 0;

uncached:
        STACK_WIND (frame, metadata_opendir_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->opendir, loc, fd, xdata);
        return 0;
}

int32_t
metadata_fstat (call_frame_t *frame, xlator_t *this, fd_t *fd, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_fstat fd->pid=[%ld]", fd->pid);
        //int                   _fd      = -1;
        int32_t               op_ret   = -1;
        int32_t               op_errno = 0;
        struct iatt           buf      = {0,};
        //struct mtdata_fd      *pfd      = NULL;
        metadata_private_t   *priv     = NULL;


        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (fd, uncached);

        priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;
        //MAKE_INODE_HANDLE (real_path, this, loc, &buf);

/*

        ret = posix_fd_ctx_get (fd, this, &pfd);
        if (ret < 0) {
                gf_log (this->name, GF_LOG_WARNING,
                        "pfd is NULL, fd=%p", fd);
                op_errno = -ret;
                goto uncached;
        }

        _fd = pfd->fd;

        op_ret = posix_fdstat (this, _fd, &buf);
        if (op_ret == -1) {
                op_errno = errno;
                gf_log (this->name, GF_LOG_ERROR, "fstat failed on fd=%p: %s",
                        fd, strerror (op_errno));
                goto uncached;
        }
*/

        op_ret = 0;

        MTDATA_STACK_UNWIND(fstat, frame, op_ret, op_errno, &buf, NULL);
        return 0;

uncached:
		gf_log (this->name, GF_LOG_INFO, "++Goto posix fstat uncache !" );
        STACK_WIND (frame, metadata_fstat_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fstat, fd, xdata);
        return 0;
}

int32_t
metadata_fsync (call_frame_t *frame, xlator_t *this, fd_t *fd,
                      int32_t flags, dict_t *xdata)
{
        STACK_WIND (frame, metadata_fsync_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fsync, fd, flags, xdata);
        return 0;
}

int32_t
metadata_flush (call_frame_t *frame, xlator_t *this, fd_t *fd, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_flush ");

gf_log (this->name, GF_LOG_INFO, "++Goto posix flush uncache !" );
        STACK_WIND (frame, metadata_flush_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->flush, fd, xdata);
        return 0;
}

int32_t
metadata_writev (call_frame_t *frame, xlator_t *this, fd_t *fd,
                       struct iovec *vector, int32_t count, off_t off,
                       uint32_t flags, struct iobref *iobref, dict_t *xdata)
{
        STACK_WIND (frame, metadata_writev_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->writev, fd, vector, count, off,
                    flags, iobref, xdata);
        return 0;
}

int32_t
metadata_readv (call_frame_t *frame, xlator_t *this, fd_t *fd,
                      size_t size, off_t offset, uint32_t flags, dict_t *xdata)
{
        STACK_WIND (frame, metadata_readv_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->readv, fd, size, offset, flags, xdata);
        return 0;
}


int32_t
metadata_open (call_frame_t *frame, xlator_t *this, loc_t *loc,
                     int32_t flags, fd_t *fd, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "metadata open  %s" ,loc->path);
#if 0
        int32_t               op_ret       = -1;
        int32_t               op_errno     = 0;
        char                 *real_path    = NULL;
        int32_t               _fd          = -1;
        struct mtdata_fd      *pfd          = NULL;
        struct iatt           stbuf        = {0, };
		metadata_private_t   *priv         = NULL;

        //DECLARE_OLD_FS_ID_VAR;

        VALIDATE_OR_GOTO (frame, out);
        VALIDATE_OR_GOTO (this, out);
        VALIDATE_OR_GOTO (loc, out);
        VALIDATE_OR_GOTO (fd, out);

        priv = this->private;
        VALIDATE_OR_GOTO (priv, out);

        //MAKE_INODE_HANDLE (real_path, this, loc, &stbuf);
        op_ret = -1;
        //SET_FS_ID (frame->root->uid, frame->root->gid);

		if(!priv->load_metadata_complete)
			goto uncached;

		op_ret = metadata_inode_iatt_get (this, loc, &buf);
        if (op_ret == -1) {
                op_errno = errno;
                gf_log (this->name, (op_errno == ENOENT)?
                        GF_LOG_DEBUG:GF_LOG_ERROR,
                        "lstat on %s failed: %s", loc->path,
                        strerror (op_errno));
                goto uncached;
        }

        if (priv->o_direct)
                flags |= O_DIRECT;

        _fd = open (real_path, flags, 0);
        if (_fd == -1) {
                op_ret   = -1;
                op_errno = errno;
                gf_log (this->name, GF_LOG_ERROR,
                        "open on %s: %s", real_path, strerror (op_errno));
                goto out;
        }

        pfd = GF_CALLOC (1, sizeof (*pfd), gf_posix_mt_posix_fd);
        if (!pfd) {
                op_errno = errno;
                goto out;
        }

        pfd->flags = flags;
        pfd->fd    = _fd;

        op_ret = fd_ctx_set (fd, this, (uint64_t)(long)pfd);
        if (op_ret)
                gf_log (this->name, GF_LOG_WARNING,
                        "failed to set the fd context path=%s fd=%p",
                        real_path, fd);

        LOCK (&priv->lock);
        {
                priv->nr_files++;
        }
        UNLOCK (&priv->lock);

        op_ret = 0;

        if (op_ret == -1) {
                if (_fd != -1) {
                        close (_fd);
                }
        }

        //SET_TO_OLD_FS_ID ();

        STACK_UNWIND_STRICT (open, frame, op_ret, op_errno, fd, xdata);

        return 0;

uncached:
#endif
        STACK_WIND (frame, metadata_open_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->open, loc, flags, fd, xdata);
        return 0;
}

int32_t
metadata_create (call_frame_t *frame, xlator_t *this, loc_t *loc,
                       int32_t flags, mode_t mode, mode_t umask, fd_t *fd,
                       dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_create  path=[%s],loc->name=[%s]", loc->path ,loc->name);
		metadata_local_t *local = NULL;

        local = metadata_local_get (frame);

        loc_copy (&local->loc, loc);
        local->xattr = dict_ref (xdata);

        STACK_WIND (frame, metadata_create_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->create, loc, flags, mode, umask,
                    fd, xdata);
        return 0;
}

int32_t
metadata_link (call_frame_t *frame, xlator_t *this, loc_t *oldloc,
                     loc_t *newloc, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_link oldloc->path=[%s],name=[%s], newloc->path=[%s],name=[%s]", 
				oldloc->path, newloc->path, oldloc->name, newloc->name);

		metadata_local_t *local = NULL;

        local = metadata_local_get (frame);

        loc_copy (&local->loc, oldloc);
        loc_copy (&local->loc2, newloc);
        local->xattr = dict_ref (xdata);

        STACK_WIND (frame, metadata_link_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->link, oldloc, newloc, xdata);
        return 0;
}

int32_t
metadata_rename (call_frame_t *frame, xlator_t *this, loc_t *oldloc,
                       loc_t *newloc, dict_t *xdata)
{
        STACK_WIND (frame, metadata_rename_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->rename, oldloc, newloc, xdata);
        return 0;
}


int
metadata_symlink (call_frame_t *frame, xlator_t *this,
                        const char *linkpath, loc_t *loc, mode_t umask,
                        dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_symlink loc->path=[%s], linkpath=[%s]", loc->path, linkpath);
		metadata_local_t *local = NULL;

        local = metadata_local_get (frame);

        loc_copy (&local->loc, loc);
		local->linkname = gf_strdup (linkpath);

        local->xattr = dict_ref (xdata);

        STACK_WIND (frame, metadata_symlink_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->symlink, linkpath, loc, umask,
                    xdata);
        return 0;
}

int32_t
metadata_rmdir (call_frame_t *frame, xlator_t *this, loc_t *loc,
                      int flags, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_rmdir  path=[%s],loc->name=[%s]", loc->path ,loc->name);
		metadata_local_t *local = NULL;

        local = metadata_local_get (frame);

        loc_copy (&local->loc, loc);
        local->xattr = dict_ref (xdata);

        STACK_WIND (frame, metadata_rmdir_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->rmdir, loc, flags, xdata);
        return 0;
}

int32_t
metadata_unlink (call_frame_t *frame, xlator_t *this, loc_t *loc,
                       int xflag, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_unlink path=[%s],loc->name=[%s]", loc->path ,loc->name);
		metadata_local_t *local = NULL;

        local = metadata_local_get (frame);

        loc_copy (&local->loc, loc);
        local->xattr = dict_ref (xdata);

        STACK_WIND (frame, metadata_unlink_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->unlink, loc, xflag, xdata);
        return 0;
}

int
metadata_mkdir (call_frame_t *frame, xlator_t *this, loc_t *loc,
                      mode_t mode, mode_t umask, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_mkdir  path=[%s],loc->name=[%s]", loc->path ,loc->name);
		metadata_local_t *local = NULL;

        local = metadata_local_get (frame);

        loc_copy (&local->loc, loc);
        local->xattr = dict_ref (xdata);

        STACK_WIND (frame, metadata_mkdir_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->mkdir, loc, mode, umask, xdata);
        return 0;
}


int
metadata_mknod (call_frame_t *frame, xlator_t *this, loc_t *loc,
                      mode_t mode, dev_t rdev, mode_t umask, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_mkmod loc->path=%s", loc->path);
        STACK_WIND (frame, metadata_mknod_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->mknod, loc, mode, rdev, umask,
                    xdata);
        return 0;
}

int32_t
metadata_readlink (call_frame_t *frame, xlator_t *this, loc_t *loc,
                         size_t size, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_readlink loc->path=%s, size=[%ld]", loc->path, size);
        char *  dest      = NULL;
        int32_t op_ret    = -1;
        int32_t op_errno  = 0;
        //char *  real_path = NULL;
        struct iatt stbuf = {0,};
        //DECLARE_OLD_FS_ID_VAR;
        metadata_private_t     *priv      = NULL;
		
		priv = this->private;

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (loc, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

        VALIDATE_OR_GOTO (priv, uncached);


        //SET_FS_ID (frame->root->uid, frame->root->gid);

        dest = alloca (size + 1);

		op_ret = metadata_inode_iatt_get (priv, loc, &stbuf);
        if (op_ret == -1) {
                op_errno = errno;
                gf_log (this->name, (op_errno == ENOENT)?
                        GF_LOG_DEBUG:GF_LOG_ERROR,
                        "lstat on %s failed: %s", loc->path,
                        strerror (op_errno));
                goto uncached;
        }

		op_ret = metadata_fsnode_lkname_get (this, loc, dest);
        if (op_ret == -1) {
                op_errno = errno;
                gf_log (this->name, (op_errno == ENOENT)?
                        GF_LOG_DEBUG:GF_LOG_ERROR,
                        "lstat on %s failed: %s", loc->path,
                        strerror (op_errno));
                goto uncached;
        }

		op_ret = strlen(dest);
        dest[op_ret] = 0;
gf_log (this->name, GF_LOG_INFO, "Test for readlink dest=[%s], op_ret=[%d]", dest, op_ret);

        //SET_TO_OLD_FS_ID ();

        MTDATA_STACK_UNWIND(readlink, frame, op_ret, op_errno, dest, &stbuf, xdata);
		return 0;
        

uncached:
		gf_log (this->name, GF_LOG_INFO, "++Goto posix readlink  op_ret=[%d]!", op_ret);
        STACK_WIND (frame, metadata_readlink_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->readlink, loc, size, xdata);
        return 0;
}


int32_t
metadata_access (call_frame_t *frame, xlator_t *this, loc_t *loc,
                       int32_t mask, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "Begin goto metadata_access loc->path=%s, mask=[%d]", loc->path, mask);
        int32_t                 op_ret    = -1;
        int32_t                 op_errno  = 0;
        //char                   *real_path = NULL;
        metadata_private_t     *priv      = NULL;

        //DECLARE_OLD_FS_ID_VAR;
        //SET_FS_ID (frame->root->uid, frame->root->gid);

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (loc, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

        VALIDATE_OR_GOTO (priv, uncached);

        //MAKE_INODE_HANDLE (real_path, this, loc, NULL);

        op_ret = access (loc->path, mask & 07);
        if (op_ret == -1) {
                op_errno = errno;
                gf_log (this->name, GF_LOG_ERROR, "access failed on %s: %s",
                        loc->path, strerror (op_errno));
                goto uncached;
        }
        op_ret = 0;

		gf_log (this->name, GF_LOG_INFO, "++Goto metadata_access  op_ret=[%d]!", op_ret);
        MTDATA_STACK_UNWIND(access, frame, op_ret, op_errno, xdata);
        return 0;

uncached:
        //SET_TO_OLD_FS_ID ();
		gf_log (this->name, GF_LOG_INFO, "++Goto posix access  op_ret=[%d]!", op_ret);
        STACK_WIND (frame, metadata_access_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->access, loc, mask, xdata);
        return 0;
}

int32_t
metadata_ftruncate (call_frame_t *frame, xlator_t *this, fd_t *fd,
                          off_t offset, dict_t *xdata)
{
        STACK_WIND (frame, metadata_ftruncate_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->ftruncate, fd, offset, xdata);
        return 0;
}

int32_t
metadata_getxattr (call_frame_t *frame, xlator_t *this, loc_t *loc,
                         const char *name, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "metadata getxattr path=[%s],name=[%s], loc->gfid=[%02x%02x%02x%02x], loc->pargfid=[%02x%02x%02x%02x]",
            loc->path,loc->name ,
            loc->gfid[12], loc->gfid[13],loc->gfid[14], loc->gfid[15],                                                                    
            loc->pargfid[12], loc->pargfid[13],loc->pargfid[14], loc->pargfid[15]);                                                       

		metadata_private_t         *priv      = NULL;
		dict_t                     *xattr      = NULL;
		int32_t               op_ret         = -1;
        int32_t               op_errno       = 0;

		//DECLARE_OLD_FS_ID_VAR;
        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (loc, uncached);

		//SET_FS_ID (frame->root->uid, frame->root->gid);  //??

		op_ret = -1;
		priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

        xattr = dict_new ();
        if (!xattr) {
			op_errno = ENOMEM;
            goto uncached;
        }

#if 0
		op_ret = metadata_inode_xatt_get (this, loc, xattr);
		if (op_ret != 0)
			goto uncached;
#endif

/*
		if (!xattr || !dict_get (xattr, (char *)name)) {
			op_ret = -1;
			op_errno = ENODATA;
		}
*/
		gf_log (this->name, GF_LOG_INFO, "metadata getxattr Test op_ret=[%d], op_errno=[%d] ", op_ret, op_errno);
		gf_log (this->name, GF_LOG_INFO, "metadata getxattr key=[%s], value=[%s] ", xattr->members_list->key, xattr->members_list->value->data);

        //SET_TO_OLD_FS_ID ();

        MTDATA_STACK_UNWIND(getxattr, frame, op_ret, op_errno, xattr, xdata);

        if (xattr)
                dict_unref (xattr);
        return 0;

uncached:
        //SET_TO_OLD_FS_ID ();
		gf_log (this->name, GF_LOG_INFO, "metadata getxattr uncached path=[%s], name=[%s]", loc->path, name);

        STACK_WIND (frame, metadata_getxattr_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->getxattr, loc, name, xdata);
        return 0;
}


int32_t
metadata_xattrop (call_frame_t *frame, xlator_t *this, loc_t *loc,
                        gf_xattrop_flags_t flags, dict_t *dict, dict_t *xdata)
{
        STACK_WIND (frame, metadata_xattrop_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->xattrop, loc, flags, dict, xdata);
        return 0;
}

int32_t
metadata_fxattrop (call_frame_t *frame, xlator_t *this, fd_t *fd,
                         gf_xattrop_flags_t flags, dict_t *dict, dict_t *xdata)
{
        STACK_WIND (frame, metadata_fxattrop_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fxattrop, fd, flags, dict, xdata);
        return 0;
}

int32_t
metadata_removexattr (call_frame_t *frame, xlator_t *this, loc_t *loc,
                            const char *name, dict_t *xdata)
{
        STACK_WIND (frame, metadata_removexattr_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->removexattr, loc, name, xdata);
        return 0;
}

int32_t
metadata_fremovexattr (call_frame_t *frame, xlator_t *this, fd_t *fd,
                             const char *name, dict_t *xdata)
{
        STACK_WIND (frame, metadata_fremovexattr_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fremovexattr, fd, name, xdata);
        return 0;
}

int32_t
metadata_lk (call_frame_t *frame, xlator_t *this, fd_t *fd,
                   int32_t cmd, struct gf_flock *lock, dict_t *xdata)
{
        STACK_WIND (frame, metadata_lk_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->lk, fd, cmd, lock, xdata);
        return 0;
}


int32_t
metadata_inodelk (call_frame_t *frame, xlator_t *this,
                        const char *volume, loc_t *loc, int32_t cmd,
                        struct gf_flock *lock,
                        dict_t *xdata)
{
        STACK_WIND (frame, metadata_inodelk_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->inodelk,
                    volume, loc, cmd, lock, xdata);
        return 0;
}

int32_t
metadata_finodelk (call_frame_t *frame, xlator_t *this,
                         const char *volume, fd_t *fd, int32_t cmd,
                         struct gf_flock *lock,
                         dict_t *xdata)
{
        STACK_WIND (frame, metadata_finodelk_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->finodelk,
                    volume, fd, cmd, lock, xdata);
        return 0;
}

int32_t
metadata_entrylk (call_frame_t *frame, xlator_t *this,
                        const char *volume, loc_t *loc, const char *basename,
                        entrylk_cmd cmd, entrylk_type type,
                        dict_t *xdata)
{
        STACK_WIND (frame, metadata_entrylk_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->entrylk,
                    volume, loc, basename, cmd, type, xdata);
        return 0;
}

int32_t
metadata_fentrylk (call_frame_t *frame, xlator_t *this,
                         const char *volume, fd_t *fd, const char *basename,
                         entrylk_cmd cmd, entrylk_type type,
                         dict_t *xdata)
{
        STACK_WIND (frame, metadata_fentrylk_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->fentrylk,
                    volume, fd, basename, cmd, type, xdata);
        return 0;
}

int32_t
metadata_rchecksum (call_frame_t *frame, xlator_t *this, fd_t *fd,
                          off_t offset, int32_t len,
                          dict_t *xdata)
{
        STACK_WIND (frame, metadata_rchecksum_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->rchecksum, fd, offset, len, xdata);
        return 0;
}

void
fsnode_conv_entry(fsedge *fseg,  struct dirent  *entry) 
{
//gf_log ("", GF_LOG_INFO, "fsnd->d_ino=[%ld]", fsnd->d_ino);
		entry->d_ino = fseg->d_ino;
		entry->d_off = fseg->d_off;
		entry->d_reclen = fseg->d_len;
		entry->d_type = fseg->d_type;
		strcpy(entry->d_name, fseg->name);
}

int
metadata_fill_readdir (fd_t *fd,  off_t off, size_t size,
                    gf_dirent_t *entries, xlator_t *this, int32_t skip_dirs)
{
        //off_t     					in_case    = -1;
        size_t    					filled     = 0;
        int             			count      = 0;
        char                        entrybuf[sizeof(struct dirent) + 256 + 8];
        struct dirent  		   	   *entry      = NULL;
        int32_t                     this_size  = -1;
        gf_dirent_t                *this_entry = NULL;
        //uuid_t                      rootgfid   = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
        //struct stat                 stbuf      = {0,};
        //char                       *hpath      = NULL;
        //int                         len        = 0;
        //int                         ret        = 0;

		metadata_private_t         *priv         = NULL;
		fsedge                     *fseg         = NULL;
		uint32_t                    posnode      = 0;
		
		priv = this->private;
		VALIDATE_OR_GOTO (priv, out);

gf_log ("", GF_LOG_INFO, "readdir inode->gfid=[%02x%02x]",  fd->inode->gfid[14],fd->inode->gfid[15]);
		posnode = NODEHASHPOS(fd->inode->gfid);
		if (list_empty (&priv->table->fsedges_list[posnode]))
            goto out;

		list_for_each_entry(fseg, &priv->table->fsedges_list[posnode],  fseg_list){
			// 遍历fseg， 移动偏移量到上次结束的fseg
			if(off && fseg){
				if(off == fseg->d_off){
					gf_log ("", GF_LOG_INFO, "############  off=[%ld]", off);
					break;
				}
			}
			/*第一次读off=0， 定位到list的第一个就返回 */
			if(!off)
				break;
		}

		/*不是第一次下发 ,如果链表中最后一个节点的下一个是头节点，就认为遍历结束 */
		if(off && (fseg->fseg_list.next ==  &priv->table->fsedges_list[posnode])){
			gf_log ("", GF_LOG_INFO, "Search fseg over ! !");
			goto out;
		}

		while(fseg){
            errno = 0;
			entry = NULL;
gf_log ("", GF_LOG_INFO, "fseg child fsdnode=[%02x%02x] name=[%s]", fseg->child->gfid[14], fseg->child->gfid[15], fseg->name);

			fsnode_conv_entry(fseg,  (struct dirent *)entrybuf);

			/* 遍历fsnode下所有目录和文件，赋值entry返回 */
			entry = (struct dirent *)entrybuf;
            if (!entry) {   
				gf_log ("", GF_LOG_INFO, "Readir this entry over !");
                break;
            }

			gf_log ("", GF_LOG_INFO, "fseg filled[%ld], size=[%ld]", filled, size);

            this_size = max (sizeof (gf_dirent_t),
            		sizeof (gfs3_dirplist))
                      + strlen (entry->d_name) + 1;

             if (this_size + filled > size) {
             	break;
             }
			if(filled <= size){
                this_entry = gf_dirent_for_name (entry->d_name);

                this_entry->d_off = entry->d_off;
                this_entry->d_ino = entry->d_ino;
                this_entry->d_type = entry->d_type;
/*
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_off=[%ld]", entry->d_off);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_ino=[%ld]", entry->d_ino);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_type=[%d]", entry->d_type);
gf_log ("", GF_LOG_INFO, "Readir this  entry->d_reclen=[%d]", entry->d_reclen);
*/
                list_add_tail (&this_entry->list, &entries->list);

				filled += this_size;
                count ++;
			}
				//gf_log ("", GF_LOG_INFO, "Readir this entry over ! off=[%ld], entry->d_off=[%ld]", off, entry->d_off);
			fseg = list_entry(fseg->fseg_list.next, struct _fsedge, fseg_list);

			if(&fseg->fseg_list ==  &priv->table->fsedges_list[posnode])
					break;
		}
		gf_log ("", GF_LOG_INFO, "count=[%d]", count);
out:
        return count;

}
int
metadata_readdirp_fill (xlator_t *this, fd_t *fd, gf_dirent_t *entries, dict_t *dict)
{
#if 0
        gf_dirent_t     *entry    = NULL;
        inode_table_t   *itable   = NULL;
		inode_t         *inode    = NULL;
		char            *hpath    = NULL;
		int              len      = 0;
        struct iatt      stbuf    = {0, };
		uuid_t           gfid;

		if (list_empty(&entries->list))
			return 0;

        itable = fd->inode->table;

		len = posix_handle_path (this, fd->inode->gfid, NULL, NULL, 0);
		hpath = alloca (len + 256); /* NAME_MAX */
		posix_handle_path (this, fd->inode->gfid, NULL, hpath, len);
		len = strlen (hpath);
		hpath[len] = '/';

        list_for_each_entry (entry, &entries->list, list) {
		memset (gfid, 0, 16);
		inode = inode_grep (fd->inode->table, fd->inode,
				    entry->d_name);
		if (inode)
			uuid_copy (gfid, inode->gfid);

		strcpy (&hpath[len+1], entry->d_name);

                posix_pstat (this, gfid, hpath, &stbuf);

		if (!inode)
			inode = inode_find (itable, stbuf.ia_gfid);

		if (!inode)
			inode = inode_new (itable);

		entry->inode = inode;

                if (dict) {
                        entry->dict =
                                posix_entry_xattr_fill (this, entry->inode,
                                                        fd, entry->d_name,
                                                        dict, &stbuf);
                        dict_ref (entry->dict);
                }

                entry->d_stat = stbuf;
                if (stbuf.ia_ino)
                        entry->d_ino = stbuf.ia_ino;
		inode = NULL;
        }
#endif

	return 0;
}

int32_t
metadata_do_readdir (call_frame_t *frame, xlator_t *this,
                  fd_t *fd, size_t size, off_t off, int whichop, dict_t *dict)
{
        struct mtdata_fd      *pfd            = NULL;
        //DIR                  *dir            = NULL;
        int                   ret            = -1;
        int                   count          = 0;
        int32_t               op_ret         = -1;
        int32_t               op_errno       = 0;
        gf_dirent_t           entries;
        int32_t               skip_dirs      = 0;
		metadata_private_t   *priv           = NULL;

        VALIDATE_OR_GOTO (frame, out);
        VALIDATE_OR_GOTO (this, out);
        VALIDATE_OR_GOTO (fd, out);

        INIT_LIST_HEAD (&entries.list);

		priv = this->private;
		VALIDATE_OR_GOTO (priv, out);

        ret = metadata_fd_ctx_get (fd, this, &pfd);
        if (ret < 0) {
                gf_log (this->name, GF_LOG_WARNING,
                        "pfd is NULL, fd=%p", fd);
                op_errno = -ret;
                goto out;
        }
gf_log (this->name, GF_LOG_WARNING, "fd->value=[%ld]", fd->_ctx->value1);

/*
        dir = pfd->dir;

        if (!dir) {
                gf_log (this->name, GF_LOG_WARNING,
                        "dir is NULL for fd=%p", fd);
                op_errno = EINVAL;
                goto out;
		}
*/
        /* When READDIR_FILTER option is set to on, we can filter out
		* directory's entry from the entry->list.
		**/
        ret = dict_get_int32 (dict, GF_READDIR_SKIP_DIRS, &skip_dirs);

		LOCK (&fd->lock);
		{
		/* posix_fill_readdir performs multiple separate individual
		 * readdir() calls to fill up the buffer.
 		 * 
		 * In case of NFS where the same anonymous FD is shared between
		 * different applications, reading a common directory can
		 * result in the anonymous fd getting re-used unsafely between
		 * the two readdir requests (in two different io-threads).
 		 *
		 * It would also help, in the future, to replace the loop
		 * around readdir() with a single large getdents() call.
		 * */
			count = metadata_fill_readdir (fd, off, size, &entries, this,
					    skip_dirs);
		}
		UNLOCK (&fd->lock);
        /* pick ENOENT to indicate EOF */
        op_errno = errno;
        op_ret = count;

gf_log (THIS->name, GF_LOG_INFO, "222000================Test=====count=[%d], off[%ld], errno=[%d] &entries=[%p]", count, off, op_errno,&entries);
        if (whichop != GF_FOP_READDIRP)
                goto out;

		metadata_readdirp_fill (this, fd, &entries, dict);

out:
        STACK_UNWIND_STRICT (readdir, frame, op_ret, op_errno, &entries, NULL);

        gf_dirent_free (&entries);

        return 0;
}

int32_t
metadata_readdir (call_frame_t *frame, xlator_t *this, fd_t *fd,
                        size_t size, off_t off,
                        dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata readdir  fd->pid=[%ld], fd->value=[%ld]", fd->pid, fd->_ctx->value1);
		metadata_private_t         *priv = NULL;

		priv = this->private;
		VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

		metadata_do_readdir (frame, this, fd, size, off, GF_FOP_READDIR, xdata);
		return 0;

uncached:
		gf_log (this->name, GF_LOG_INFO, "++Goto posix readdir uncache. ");
        STACK_WIND (frame, metadata_readdir_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->readdir, fd, size, off, xdata);
        return 0;
}

int32_t
metadata_readdirp (call_frame_t *frame, xlator_t *this, fd_t *fd,
                         size_t size, off_t off, dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata readdirp  fd->pid =[%ld],size=[%ld] fd->value=[%ld]", fd->pid,size, fd->_ctx->value1);
		metadata_private_t         *priv = NULL;

		priv = this->private;
		VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

		metadata_do_readdir (frame, this, fd, size, off, GF_FOP_READDIRP, xdata);
		return 0;

uncached:
		gf_log (this->name, GF_LOG_INFO, "++Goto posix readdirp uncache. ");
        STACK_WIND (frame, metadata_readdirp_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->readdirp, fd, size, off, xdata);
        return 0;
}

int32_t
metadata_setattr (call_frame_t *frame, xlator_t *this, loc_t *loc,
                        struct iatt *stbuf, int32_t valid,
                        dict_t *xdata)
{
        STACK_WIND (frame, metadata_setattr_cbk, FIRST_CHILD (this),
                    FIRST_CHILD (this)->fops->setattr, loc, stbuf, valid, xdata);
        return 0;
}

int32_t
metadata_truncate (call_frame_t *frame, xlator_t *this, loc_t *loc,
                         off_t offset,
                         dict_t *xdata)
{
        STACK_WIND (frame, metadata_truncate_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->truncate, loc, offset, xdata);
        return 0;
}

int32_t
metadata_stat (call_frame_t *frame, xlator_t *this, loc_t *loc,
                     dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "++Begin metadata_stat path=[%s]", loc->path);
        struct iatt           buf         = {0,};
        int32_t               op_ret      = -1;
        int32_t               op_errno    = 0;
        metadata_private_t  *priv  = NULL;

        //DECLARE_OLD_FS_ID_VAR;

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (loc, uncached);

        priv = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

        //SET_FS_ID (frame->root->uid, frame->root->gid);

        //MAKE_INODE_HANDLE (real_path, this, loc, &buf);

		op_ret = metadata_inode_iatt_get (priv, loc, &buf);
        if (op_ret == -1) {
                op_errno = errno;
                gf_log (this->name, (op_errno == ENOENT)?
                        GF_LOG_DEBUG:GF_LOG_ERROR,
                        "lstat on %s failed: %s", loc->path,
                        strerror (op_errno));
                goto uncached;
        }

        op_ret = 0;

        //SET_TO_OLD_FS_ID();
		gf_log (this->name, GF_LOG_INFO, "++Goto metadata_stat op_ret=[%d]!", op_ret);
        MTDATA_STACK_UNWIND(stat, frame, op_ret, op_errno, &buf, xdata);

        return 0;

uncached:
		gf_log (this->name, GF_LOG_INFO, "++Goto posix stat uncache op_ret=[%d]!", op_ret);

        STACK_WIND (frame, metadata_stat_cbk, FIRST_CHILD(this),
                    FIRST_CHILD(this)->fops->stat, loc, xdata);
        return 0;
}

int32_t
metadata_lookup (call_frame_t *frame, xlator_t *this, loc_t *loc,
                       dict_t *xdata)
{
gf_log (this->name, GF_LOG_INFO, "00-metadata lookup path=[%s] ,name=[%s], loc->gfid=[%02x%02x%02x%02x], loc->pargfid=[%02x%02x%02x%02x]",   
			loc->path, loc->name,
			loc->gfid[12], loc->gfid[13],loc->gfid[14], loc->gfid[15], 
			loc->pargfid[12], loc->pargfid[13],loc->pargfid[14], loc->pargfid[15]);
//如果元数据加载标志是完成，则需要查询metadata层缓存，然后返回给上层
//如果元数据加载未完成，则直接发给posix层查询磁盘
        int32_t     				op_ret       = -1;
//        int32_t				        entry_ret = 0;
        int32_t     				op_errno     = 0;
        struct iatt                 stbuf        = {0, };
        struct iatt                 postparent   = {0, };
		//struct iatt                 buf  = {0, };
		int32_t                     gfidless     = 0;
        dict_t                     *xattr_rsp    = NULL;
		dict_t                     *xattr_alloc  = NULL;
		metadata_private_t         *priv         = NULL;

        VALIDATE_OR_GOTO (frame, uncached);
        VALIDATE_OR_GOTO (this, uncached);
        VALIDATE_OR_GOTO (loc, uncached);

		priv  = this->private;
        VALIDATE_OR_GOTO (priv, uncached);

		if(!priv->load_metadata_complete)
			goto uncached;

        if (__is_root_gfid (loc->pargfid) &&
            (!loc->name)) {
                gf_log (this->name, GF_LOG_WARNING,
                        "Lookup issued on %s, which is not permitted",
                        GF_HIDDEN_PATH);
                op_errno = EPERM;
                op_ret = -1;
                goto uncached;
        }

        op_ret = dict_get_int32 (xdata, GF_GFIDLESS_LOOKUP, &gfidless);
        op_ret = -1;

        op_ret = metadata_inode_iatt_get (priv, loc, &stbuf);
        if (op_ret != 0)
                goto uncached;
gf_log (this->name, GF_LOG_INFO, "00-metadata lookup stbuf->gfid=[%02x%02x%02x%02x]",
			stbuf.ia_gfid[12], stbuf.ia_gfid[13],stbuf.ia_gfid[14], stbuf.ia_gfid[15]);

        op_ret = metadata_parinode_iatt_get (priv, loc, &postparent);
        if (op_ret != 0)
                goto uncached;
	
		op_errno = errno;

        if (op_ret == -1) {
			if (op_errno != ENOENT) {
                    gf_log (this->name, GF_LOG_ERROR,
                            "lstat on %s failed: %s",
                            loc->path, strerror (op_errno));
            }
            //entry_ret = -1;
            //goto parent;
        }

//需要从fsnode中的xattr_array中获取每个fsnode的扩展属性 
        if (xdata && (op_ret == 0)) {
            xattr_rsp = metadata_lookup_xattr_get (this, loc,
                                             xdata, &stbuf);
        }

/*
		if(xdata){
        	op_ret = metadata_inode_xatt_get (this, loc, &xattr_rsp);
            if (op_ret != 0)
            	goto uncached;

            if (!metadata_xattr_satisfied (this, xdata, xattr_rsp))
            	goto uncached;
			//xattr_rsp = metadata_lookup_xattr_get(this, loc, xdata, &stbuf);
		}
*/

		//加载完成
        if (!op_ret && !gfidless && uuid_is_null (stbuf.ia_gfid)) {
                gf_log (this->name, GF_LOG_ERROR, "buf->ia_gfid is null for "
                        "%s", (loc->path) ? loc->path: "");
                op_ret = -1;
                op_errno = ENODATA;
        }

		MTDATA_STACK_UNWIND(lookup, frame, op_ret, op_errno, (loc)?loc->inode:NULL, &stbuf,
                         xattr_rsp, &postparent);
	    if (xattr_rsp)
            dict_unref (xattr_rsp);

		return 0;

uncached:
		gf_log (this->name, GF_LOG_INFO, "++Goto posix lookup uncache op_ret=[%d]!", op_ret);

		if (!xdata)
			xdata = xattr_alloc = dict_new ();
		if (xdata)
			metadata_load_reqs (this, xdata);

    	STACK_WIND (frame, metadata_lookup_cbk, FIRST_CHILD(this),
                   FIRST_CHILD(this)->fops->lookup, loc, xdata);
		//dict_foreach (xdata, metadata_xattr_get, NULL);
    	if (xattr_rsp)
        	dict_unref (xattr_rsp);

		if (xattr_alloc)
			dict_unref (xattr_alloc);

        return 0;
}

int32_t
metadata_fsetattr (call_frame_t *frame, xlator_t *this, fd_t *fd,
                         struct iatt *stbuf, int32_t valid,
                         dict_t *xdata)
{
        STACK_WIND (frame, metadata_fsetattr_cbk, FIRST_CHILD (this),
                    FIRST_CHILD (this)->fops->fsetattr, fd, stbuf, valid, xdata);
        return 0;
}

int
metadata_build_child_loc (xlator_t *this, loc_t *child, loc_t *parent, char *name)
{
        if (!child) {
                goto err;
        }

        if (strcmp (parent->path, "/") == 0)
                gf_asprintf ((char **)&child->path, "/%s", name);
        else
                gf_asprintf ((char **)&child->path, "%s/%s", parent->path, name);

        if (!child->path) {
                goto err;
        }

        child->name = strrchr (child->path, '/');
        if (child->name)
                child->name++;

        child->parent = inode_ref (parent->inode);
        child->inode = inode_new (parent->inode->table);

        if (!child->inode) {
                goto err;
        }

        return 0;
err:
        loc_wipe (child);
        return -1;
}
int32_t
metadata_file_layout(xlator_t *this, loc_t *loc, gf_dirent_t *entry, 
				char **lkname, dict_t *dict)
{
		int                      ret            = -1;
		loc_t                    entry_loc      = {0,};
		//gf_dirent_t              entries;

        gf_log (this->name, GF_LOG_INFO, "migrate data called on %s", loc->path);

		loc_wipe (&entry_loc);

        ret =metadata_build_child_loc (this, &entry_loc, loc,
                                                  entry->d_name);
        if (ret) {
        	gf_log (this->name, GF_LOG_ERROR, "Child loc"
        	" build failed");
        	goto out;
        }

        if (uuid_is_null (entry->d_stat.ia_gfid)) {
        		gf_log (this->name, GF_LOG_ERROR, "%s/%s"
        		"gfid not present", loc->path,
        		entry->d_name);
                //continue;
        }
        entry_loc.inode->ia_type = entry->d_stat.ia_type;

		uuid_copy (entry_loc.gfid, entry->d_stat.ia_gfid);
        uuid_copy (entry_loc.inode->gfid, entry->d_stat.ia_gfid); /* 构建inode的gfid */

        if (uuid_is_null (loc->gfid)) {
        		gf_log (this->name, GF_LOG_ERROR, "%s/%s"
        		"gfid not present", loc->path,
        			entry->d_name);
                //continue;
        }

        uuid_copy (entry_loc.pargfid, loc->gfid);

        if (IA_ISLNK (entry->d_stat.ia_type)){
        	ret = syncop_readlink (this, &entry_loc, lkname, 
							entry->d_stat.ia_size);
        	if (ret < 0) {
        			gf_log (this->name, GF_LOG_WARNING,
        			"%s: readlink on symlink failed (%s)",
        			entry_loc.path, strerror (errno));
        		goto out;
        	}
        	gf_log (this->name, GF_LOG_ERROR, "This is link file name=[%s],linkname=[%s]", entry->d_name, *lkname);
		}
        ret = syncop_getxattr (this, &entry_loc, &dict,
        							NULL);
		if (ret < 0) {
        	gf_log (this->name, GF_LOG_TRACE, "failed to "
                     "get link-to key for %s",
                     	entry_loc.path);
             goto out;
		}

/*
   ret = syncop_lookue (this, &entry_loc, NULL, &iatt,
                                             NULL, NULL);
        if (ret) {
               gf_log (this->name, GF_LOG_ERROR, "%s"
               " lookup failed", entry_loc.path);
               continue;
		}
*/

out:
        loc_wipe (&entry_loc);

        return ret;
}

int32_t
metadata_direct_layout(xlator_t *this, mt_defrag_info_t *defrag, loc_t *loc,
					fsedge *fseg,  fsnode *fsnd, dict_t *mtdata_dict)
{
        int                      ret            = -1;
		loc_t                    entry_loc      = {0,};
		fd_t                     *fd            = NULL;
        gf_dirent_t              entries;
        gf_dirent_t             *tmp            = NULL;
        gf_dirent_t             *entry          = NULL;
        gf_boolean_t             free_entries   = _gf_false;
        //dict_t                  *dict           = NULL;
        off_t                    offset         = 0;
        struct iatt              iatt           = {0,};
        int                      readdirp_errno = 0;
		struct timeval           start          = {0,};
//----------------------->
    	metadata_private_t     *priv = NULL;
		fsnode                 *newfsnode = NULL;
		fsnode                 *hd_fsnode = NULL;
		fsedge                 *newfsedge = NULL;
		char                   *linkname  = NULL;
//----------------------->
		priv = this->private;
    	if (!priv)
       		goto out;

        ret = syncop_lookup (this, loc, NULL, &iatt, NULL, NULL);
        if (ret) {
                gf_log (this->name, GF_LOG_ERROR, "Lookup failed on %s",
                        loc->path);
                goto out;
        }		
		
        fd = fd_create (loc->inode, defrag->pid);
        if (!fd) {
                gf_log (this->name, GF_LOG_ERROR, "Failed to create fd");
                ret = -1;
                goto out;
        }

        ret = syncop_opendir (this, loc, fd);
        if (ret) {
                gf_log (this->name, GF_LOG_ERROR, "Failed to open dir %s",
                        loc->path);
                ret = -1;
                goto out;
        }
gf_log (this->name, GF_LOG_ERROR, "Test for fd fd-value=[%ld] ,path=[%s],name=[%s]", fd->_ctx->value1, loc->path, loc->name);

		INIT_LIST_HEAD (&entries.list);
       	while ((ret = syncop_readdirp (this, fd, 131072, offset, NULL,
                &entries)) != 0)
        {
                if (ret < 0) {
                        gf_log (this->name, GF_LOG_ERROR, "Readdir returned %s"
                                ". Aborting fix-layout",strerror(errno));
                        goto out;
                }

                /* Need to keep track of ENOENT errno, that means, there is no
 *                    need to send more readdirp() */
                readdirp_errno = errno;

                if (list_empty (&entries.list))
                        break;

                free_entries = _gf_true;

                list_for_each_entry_safe(entry, tmp, &entries.list, list) {
                        offset = entry->d_off;

                        if (!strcmp (entry->d_name, ".") ||
                            !strcmp (entry->d_name, ".."))
                                continue;

        gf_log (this->name, GF_LOG_INFO, "metadata layout d_name=%s, ia_gfid=[%02x%02x], ia_type=[%d], ia_ino=[%ld], ia_nlink=[%d]",
						entry->d_name, entry->d_stat.ia_gfid[14], entry->d_stat.ia_gfid[15],
						entry->d_stat.ia_type , entry->d_stat.ia_ino, entry->d_stat.ia_nlink);

/* 建树  
        gf_log (this->name, GF_LOG_INFO, "+++++++++++++++++++++loc->gfid=[%02x%02x%02x%02x], loc->pargfid=[%02x%02x%02x%02x]",
						loc->gfid[12],loc->gfid[13], loc->gfid[14], loc->gfid[15],
						loc->pargfid[12],loc->pargfid[13], loc->pargfid[14], loc->pargfid[15]);
*/

//entry中dict中是否保存扩展属性

/*
					ret = syncop_getxattr (this, loc, &dict, NULL);
					if (ret < 0) {
                         gf_log (this->name, GF_LOG_TRACE, "failed to "
                                    "get link-to key for %s",
                                    entry_loc.path);
                         continue;
                    }
*/
// For Hard nlink 
					linkname = NULL;
                    if (IA_ISLNK (entry->d_stat.ia_type)){
							metadata_file_layout(this,  loc, entry, &linkname, mtdata_dict);
							gf_log("", GF_LOG_ERROR, "fsnode link name =[%s]", linkname);
					}

					int hdflag = 0;
					if(IA_ISREG (entry->d_stat.ia_type) )
					{
					
						hd_fsnode = fsnodes_hdlk_node_find(entry, fseg, priv->table, &hdflag);
						if(hdflag == 0)
						{
							//第一个硬链接文件	
        					gf_log (this->name, GF_LOG_INFO, "+++++++++first hard link file hdflag=[%d]", hdflag);
							newfsnode = fsnodes_node_create(mtdata_dict, entry, fseg, fsnd);
							newfsedge = fsedges_edge_create(entry, fsnd, newfsnode,linkname, hdflag);
							add_fsnode_to_hash_table(loc->gfid, newfsnode, newfsedge, priv->table);
						}else
						{
        					gf_log (this->name, GF_LOG_INFO, "Begin create hard link fsdege hdflag=[%d]", hdflag);
							newfsedge = fsedges_edge_create(entry, fsnd, hd_fsnode,linkname, hdflag);
							add_fsnode_to_hash_table(loc->gfid, NULL, newfsedge, priv->table);
						}
					}else
					{
						newfsnode = fsnodes_node_create(mtdata_dict, entry, fseg, fsnd );
						newfsedge = fsedges_edge_create(entry, fsnd, newfsnode, linkname, hdflag);
						add_fsnode_to_hash_table(loc->gfid, newfsnode, newfsedge, priv->table);
					}

/* End add */
                        if (!IA_ISDIR (entry->d_stat.ia_type))
                                continue;

                        defrag->num_files_lookedup++;
                        if (defrag->stats == _gf_true) {
                                gettimeofday (&start, NULL);
                        }
                        loc_wipe (&entry_loc);

                        ret =metadata_build_child_loc (this, &entry_loc, loc,
                                                  entry->d_name);
                        if (ret) {
                                gf_log (this->name, GF_LOG_ERROR, "Child loc"
                                        " build failed");
                                goto out;
                        }

                        if (uuid_is_null (entry->d_stat.ia_gfid)) {
                                gf_log (this->name, GF_LOG_ERROR, "%s/%s"
                                        "gfid not present", loc->path,
                                         entry->d_name);
                                continue;
                        }
                        entry_loc.inode->ia_type = entry->d_stat.ia_type;

                        uuid_copy (entry_loc.gfid, entry->d_stat.ia_gfid);
                        uuid_copy (entry_loc.inode->gfid, entry->d_stat.ia_gfid); /* 构建inode的gfid */

                        if (uuid_is_null (loc->gfid)) {
                                gf_log (this->name, GF_LOG_ERROR, "%s/%s"
                                        "gfid not present", loc->path,
                                         entry->d_name);
                                continue;
                        } 

						uuid_copy (entry_loc.pargfid, loc->gfid);

                        ret = syncop_lookup (this, &entry_loc, NULL, &iatt,
                                             NULL, NULL);
                        if (ret) {
                                gf_log (this->name, GF_LOG_ERROR, "%s"
                                        " lookup failed", entry_loc.path);
                                continue;
                        }

        				ret = syncop_getxattr (this, &entry_loc, &mtdata_dict,
        										NULL);
						if (ret < 0) {
				        	gf_log (this->name, GF_LOG_TRACE, "failed to "
                     				"get link-to key for %s", entry_loc.path);
				             goto out;
						}

                        ret = metadata_direct_layout (this, defrag, &entry_loc, 
									newfsedge, newfsnode, mtdata_dict);

                        if (ret) {
                                gf_log (this->name, GF_LOG_ERROR, "Fix layout "
                                        "failed for %s", entry_loc.path);
                                defrag->total_failures++;
                                goto out;
                        }

                }
                gf_dirent_free (&entries);
                free_entries = _gf_false;
                INIT_LIST_HEAD (&entries.list);
                if (readdirp_errno == ENOENT)
                        break;
        }

        ret = 0;
out:
        if (free_entries)
                gf_dirent_free (&entries);

        loc_wipe (&entry_loc);

        if (mtdata_dict)
                dict_unref(mtdata_dict);

        if (fd)
                fd_unref (fd);  /* 释放文件fd引用 */

        return ret;

}

void 
metadata_build_root_inode(xlator_t *this, inode_t **inode)
{
		inode_table_t         *itable      = NULL;
		uuid_t                root_gfid    = {0,} ;

		itable = inode_table_new(0, this);
		if(!itable)
			return ;

		root_gfid[15] = 1;
		*inode = inode_find(itable, root_gfid);
}

void 
metadata_build_root_loc(inode_t *inode , loc_t  *loc)
{
		loc->path = "/";
		loc->inode = inode;
		loc->inode->ia_type = IA_IFDIR;
		memset (loc->gfid, 0 , 16);
		loc->gfid[15] = 1;
}

int32_t
metadata_layout_start(void *data)
{
		xlator_t              *this        = NULL;
		metadata_private_t    *priv        = NULL;
		mt_defrag_info_t      *defrag      = NULL;
		int                   ret          = -1;
		loc_t                 loc          = {0,};
		struct iatt           iatt         = {0,};
		struct iatt           parent       = {0,};
//--------------------->
		dict_t                *mtdata_dict     = NULL;
		fsnode                *fsndroot        = NULL;
		fsedge                *fsegroot        = NULL;
//<--------------------

		this = data;
		if(!this)
			goto err;
	
		priv = this->private;
		if(!priv)
			goto err;

		defrag = priv->defrag;
		if(!defrag)
			goto err;

		gettimeofday(&defrag->start_time, NULL);
		metadata_build_root_inode(this, &defrag->root_inode);
		if(!defrag->root_inode)
			goto err;

		metadata_build_root_loc(defrag->root_inode, &loc);
		ret = syncop_lookup(this, &loc, NULL, &iatt, NULL, &parent);
		if(ret){
			gf_log(this->name, GF_LOG_ERROR, "look on / failed");
			goto err;
		}

/* 创建 /目录后，添加到fsnode树形结构的根节点 */
        mtdata_dict = dict_new ();
        if (!mtdata_dict) {
                ret = -1;
                goto err;
        }
		ret = syncop_getxattr (this, &loc, &mtdata_dict, NULL);
		if (ret < 0) {
        	gf_log (this->name, GF_LOG_TRACE, "failed to "
            		"get link-to key for %s",
                     loc.path);
        }

		fsndroot = fsnodes_rootnode_create(&loc, &iatt, mtdata_dict);

		add_fsnode_to_hash_table(loc.gfid, fsndroot, fsegroot, priv->table);
/* End add */

        ret = metadata_direct_layout (this, defrag, &loc, fsegroot, 
									fsndroot, NULL);

		priv->load_metadata_complete = 1;  /* 加载完成 */
		showFsnodes(priv);
		showFsedges(priv);
		//showRfsedge(priv);
        gf_log (this->name, GF_LOG_ERROR, "metadata layout over ret=[%d]!", ret);

		return ret;
err:
/* 缺少内容 释放内存*/
        if (defrag) {
                GF_FREE (defrag);
                priv->defrag = NULL;
        }

		return ret;
}

int                                                                           
metadata_listener_stop (xlator_t *this)                                             
{                                                                             
        zefs_ctx_t  *ctx = NULL;                                              
        cmd_args_t       *cmd_args = NULL;                                    
        int              ret = 0;                                             
                                                                              
        ctx = this->ctx;                                                      
        GF_ASSERT (ctx);                                                      
        cmd_args = &ctx->cmd_args;                                            
        if (cmd_args->sock_file) {                                            
                ret = unlink (cmd_args->sock_file);                           
                if (ret && (ENOENT == errno)) {                               
                        ret = 0;                                              
                }                                                             
        }                                                                     
                                                                              
        if (ret) {                                                            
                gf_log (this->name, GF_LOG_ERROR, "Failed to unlink listener "
                        "socket %s, error: %s", cmd_args->sock_file,          
                        strerror (errno));                                    
        }                                                                     
        return ret;                                                           
}                                                                             
static int
metadata_layout_done(int ret, call_frame_t *sync_frame, void *data)
{
/* 线程完成扫描磁盘工作后是否关闭 */
		//metadata_listener_stop (sync_frame->this);

		//STACK_DESTROY (sync_frame->root);
		//kill (getpid(), SIGTERM);
		return 0;
}

static void *
load_metadata_thread_proc (void *data)
{
        //metadata_private_t	*priv = data;
	//	priv = priv; 
        //scan all metadata from brick directory from "/" (gfid=0x01) , and construct the  nodehash table...
        int                      ret    = -1;
        call_frame_t            *frame  = NULL;
        metadata_private_t	    *priv   = NULL;
		mt_defrag_info_t        *defrag = NULL;
        xlator_t                *this   = NULL;

		this = data;
		priv = this->private;
		if(!priv)
			goto out;

		defrag = priv->defrag;

		frame = create_frame(this, this->ctx->pool);
		if(!frame)
			goto out;

		frame->root->pid = -4;
		defrag->pid = frame->root->pid;
		//defrag->defrag_status = GF_DEFRAG_STATUS_STARTED;
		
		ret = synctask_new (this->ctx->env, metadata_layout_start,
						metadata_layout_done, frame, this);
		if(ret)
			gf_log (this->name, GF_LOG_ERROR, "Could not create task for rebalance");

out:
        return NULL;
}


int32_t
mem_acct_init (xlator_t *this)
{
    int     ret = -1;

    ret = xlator_mem_acct_init (this, gf_metadata_mt_end + 1);

    return ret;
}

int
notify (xlator_t *this, int event, void *data, ...)
{

		metadata_private_t	    *priv = NULL;
		int ret = -1;
		

		priv = this->private;

		if (!priv)
				return -1;


		switch (event) {
		case GF_EVENT_CHILD_UP:
				if ((!priv->load_metadata_thread) && (priv->load_metadata_complete == 0)) {
                        //ret = pthread_create (&priv->load_metadata_thread, NULL,
                         //                     load_metadata_thread_proc, this->private);
                        ret = pthread_create (&priv->load_metadata_thread, NULL,
                                              load_metadata_thread_proc, this);
                        if (ret != 0) {
                                gf_log (this->name, GF_LOG_WARNING,
                                        "pthread_create() failed (%s)",
                                        strerror (errno));
                        }
                }
        		
				break;

		case GF_EVENT_CHILD_DOWN:
				
				break;

		case GF_EVENT_CHILD_CONNECTING:
				
				break;

		default:
				break;
		}

		ret = default_notify (this, event, data);
		
		return ret;

}


int
init (xlator_t *this)
{

    int                 ret = -1;
    metadata_private_t     *priv = NULL;
      
    if (!this->children || this->children->next) {
            gf_log (this->name, GF_LOG_ERROR,
                    "FATAL: metadata not configured with exactly "
                    "one child");
            goto out;
    }
    if (!this->parents) {
        gf_log (this->name, GF_LOG_WARNING,
                "dangling volume. check volfile ");
    }

/* Add by hf@20150320 for meta */
	GF_VALIDATE_OR_GOTO ("metadata", this, out);
	mt_defrag_info_t     *defrag        = NULL;
/* End add */

    priv = GF_CALLOC (1, sizeof (*priv), gf_metadata_mt_private_t);
    if (!priv)
        goto out;
	GF_OPTION_INIT ("total-metadata-mem-limit", priv->total_metadata_mem_limit, size, out);
    //LOCK_INIT(&priv->lock);
/* Add by hf@20150320 for tst */

    defrag = GF_CALLOC (1, sizeof (mt_defrag_info_t),
    		gf_defrag_mt_info_t);

    //defrag->is_exiting = 0;
	defrag->stats = _gf_false;

	priv->load_metadata_complete = 0;  /* 加载未完成 */
	priv->keep_metadata_partially = 0; /* 需要从磁盘上找 */
	priv->defrag = defrag;
/* End add */
    pthread_mutex_init (&priv->mutex, 0);
/* Add by hf@20150508 for priv->table */
	priv->table = metadata_node_table_init();
	if(!priv->table){
		gf_log(this->name, GF_LOG_ERROR, "Init metadata_node_table falied !");
		goto out;
	}
/* End add */
	LOCK_INIT(&priv->table->lock);

    this->private = priv;

    ret = 0;
out:
    if (ret) {
        if (priv) {
			GF_FREE (priv->defrag);
            GF_FREE (priv);
        }	
        this->private = NULL;
    }
    return ret;
}

void
fini (xlator_t *this)
{
    metadata_private_t     *priv = NULL;

    priv = this->private;
    if (!priv)
        goto out;
    this->private = NULL;
	//release priv->nodehash[] here....
	
	//LOCK_DESTROY (&priv->lock);
    pthread_mutex_destroy (&priv->mutex);
	LOCK_DESTROY (&priv->table->lock);
    GF_FREE (priv);
out:
    return;
}


struct xlator_fops fops = {
		.lookup      = metadata_lookup,
        .stat        = metadata_stat,
        .opendir     = metadata_opendir,
        .readdir     = metadata_readdir,
        .readdirp    = metadata_readdirp,
        .readlink    = metadata_readlink,
        .mknod       = metadata_mknod,
        .mkdir       = metadata_mkdir,
        .unlink      = metadata_unlink,
        .rmdir       = metadata_rmdir,
        .symlink     = metadata_symlink,
        .rename      = metadata_rename,
        .link        = metadata_link,
        .truncate    = metadata_truncate,
        .create      = metadata_create,
        .open        = metadata_open,
        .readv       = metadata_readv,
        .writev      = metadata_writev,
        .statfs      = metadata_statfs,
        .flush       = metadata_flush,
        .fsync       = metadata_fsync,
        .setxattr    = metadata_setxattr,
        .fsetxattr   = metadata_fsetxattr,
        .getxattr    = metadata_getxattr,
        .fgetxattr   = metadata_fgetxattr,
        .removexattr = metadata_removexattr,
        .fremovexattr = metadata_fremovexattr,
        .fsyncdir    = metadata_fsyncdir,
        .access      = metadata_access,
        .ftruncate   = metadata_ftruncate,
        .fstat       = metadata_fstat,
        .lk          = metadata_lk,
        .inodelk     = metadata_inodelk,
        .finodelk    = metadata_finodelk,
        .entrylk     = metadata_entrylk,
        .fentrylk    = metadata_fentrylk,
        .rchecksum   = metadata_rchecksum,
        .xattrop     = metadata_xattrop,
        .fxattrop    = metadata_fxattrop,
        .setattr     = metadata_setattr,
        .fsetattr    = metadata_fsetattr,

};

struct xlator_dumpops dumpops;

struct xlator_cbks cbks = {
};

struct volume_options options[] = {
    { .key  = {"total-metadata-mem-limit" },
      .type = GF_OPTION_TYPE_SIZET,
      .min  = 512 * GF_UNIT_MB,
      .max  = 8 * GF_UNIT_GB,
      .default_value = "2GB",
      .description = "the threshold for loading all metadata in memory , if more than this , keep metadata partially in memory",
    },
    { .key  = {NULL} },
};
//#endif
