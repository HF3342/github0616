/*
   Copyright (c) 2008-2012 Red Hat, Inc. <http://www.zecloud.cn>
   This file is part of ZeFS.

   This file is licensed to you under your choice of the GNU Lesser
   General Public License, version 3 or any later version (LGPLv3 or
   later), or the GNU General Public License, version 2 (GPLv2), in all
   cases as published by the Free Software Foundation.
*/
#ifndef _CONFIG_H
#define _CONFIG_H
#include "config.h"
#endif


//#if METADATA

#include "metadata.h"
//#include "options.h"
//#include "zefs3-xdr.h"

inline fsnode *fsnode_new (){
	fsnode * p = NULL;

	p = GF_CALLOC (1, sizeof(*p),gf_metadata_mt_fsnode_t);

	//p->xattr_array->key = (char*)malloc (strlen(p->xattr_array->key));
	//p->xattr_array->value = (char*)malloc (strlen(p->xattr_array->value));

	return p;
}

inline void fsnode_destroy (fsnode *p){
	if (p == NULL) {
		return;
	}
	GF_FREE (p);
	return;
}

inline fsedge *fsedge_new (const char *name, const char *lkname){
	fsedge * p = NULL;
	p = GF_CALLOC (1, sizeof(*p),gf_metadata_mt_fsedge_t);

	if(name)
		p->name = GF_CALLOC (1, strlen(name)+1, gf_metadata_mt_char);
	
	if(lkname)
		p->linkname = GF_CALLOC (1, strlen(lkname)+1, gf_metadata_mt_char);

	return p;
}

inline void fsedge_destroy (fsedge *p){
	if (p == NULL) {
		return;
	}
	if(p->name){
		GF_FREE (p->name);
		p->name = NULL;
	}
	if(p->linkname){
		GF_FREE (p->linkname);
		p->linkname = NULL;
	}

	GF_FREE (p);
	return;
}

void _remove_fsnode_from_hash_table(fsnode *p, metadata_node_table_t *table) {

}

void remove_fsnode_from_hash_table(fsnode *p, metadata_node_table_t *table) {

}

#if 0
fsnode *chk_hard_fsnd(fsnode *fs, gf_dirent_t  *entry, int pos, int *flag)
{
	int f = 0;
	while(fs){
		gf_log ("", GF_LOG_ERROR, "<st_ino=[%ld], ia_ino=[%ld]", fs->stat.st_ino, entry->d_stat.ia_ino);
		if(fs->stat.st_ino == entry->d_stat.ia_ino){
			gf_log ("", GF_LOG_ERROR, "<------i=[%d],next->name=[%s] ino=[%ld]", pos,fs->parents->name, entry->d_stat.ia_ino);
			f = 1;
			goto out;
		}
		fs = fs->next;
	}
out:
	*flag = f;
	return fs;
}
#endif

/* For find hard link */
fsnode *fsnodes_hdlk_node_find(gf_dirent_t  *entry, fsedge *pfseg, metadata_node_table_t *table, int *flag)
{
	uint32_t     nodepos = 0;
	uint32_t     fg      = 0;
	fsnode      *fsnd    = NULL;
	fsnode      *tmpfsnd    = NULL;

	nodepos = NODEHASHPOS(entry->d_stat.ia_gfid);

	if (list_empty (&table->fsnodes_list[nodepos]))
   		goto out;
//硬链接gfid是一样的

	list_for_each_entry_safe(fsnd, tmpfsnd, &table->fsnodes_list[nodepos], fsnd_list){
		if(fsnd){
			if(ia_type_from_st_mode (fsnd->stat.st_mode) &&
				(fsnd->stat.st_ino == entry->d_stat.ia_ino))
				gf_log ("", GF_LOG_ERROR, "<------i=[%d],next->name=[%s] ino=[%ld]", nodepos,fsnd->parents->name, entry->d_stat.ia_ino);
				fg = 1;
				goto out;
		}
	}

out:
	*flag = fg;
	return fsnd ;
}

#if 0
void shownextfsnd(fsnode *fs, int pos)
{
	if(fs != NULL){
		gf_log ("", GF_LOG_ERROR, "<------i=[%d],next->name=[%s]", pos,fs->parents->name);
		shownextfsnd(fs->next, pos);
	}
}

void shownextLfseg(fsedge *fs, int pos)
{
    if(fs != NULL){
        gf_log ("", GF_LOG_ERROR, "<---fsedge---i=[%d],next->name=[%s]", pos,fs->name);
        shownextLfseg(fs->nextparent, pos);
    }
}
#endif

#if 0
void shownextRfseg(fsedge *fs, int pos)
{
    if(fs != NULL){
        gf_log ("", GF_LOG_ERROR, "<---fsedge---i=[%d],next->name=[%s]", pos,fs->name);
        shownextRfseg(fs->nextparent, pos);
    }
}

void showfsnode(metadata_private_t  *priv)
{
	int i = 0;
gf_log ("", GF_LOG_ERROR, "<------------------------------------Begin----------------------------------->");

gf_log ("", GF_LOG_ERROR, "<--------priv->nodes=[%d]", priv->table->nodes);
gf_log ("", GF_LOG_ERROR, "<--------priv->dirnodes=[%d]", priv->table->dirnodes);
gf_log ("", GF_LOG_ERROR, "<--------priv->filenodes=[%d]", priv->table->filenodes);
//gf_log ("", GF_LOG_ERROR, "<--------priv->total_metadata_mem=[%ld]", priv->table->total_metadata_mem);
	for(i = 0; i < (1<<16); i++)
	{
		if(priv->table->fsnd_hashtable[i] != NULL)
		{
			if(priv->table->fsnd_hashtable[i]->parents != NULL)
			{
				gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->name=[%s] fsnode->gfid=[%s]", 
						i,priv->table->fsnd_hashtable[i]->parents->name, uuid_utoa(priv->table->fsnd_hashtable[i]->gfid));
			}
			shownextfsnd(priv->table->fsnd_hashtable[i]->next, i);
		}
	}

gf_log ("", GF_LOG_ERROR, "<------------------------------------End  ----------------------------------->");

}
#endif

int 
fsnode_xattr_set(dict_t *dict,  fsnode *fsnd ){
        if (!dict) {                                                                               
                gf_log_callingfn ("dict", GF_LOG_WARNING,                                          
                                  "dict is NULL");                                                 
                return -1;                                                                         
        }                                                                                          
#if 0                                                                                                   
        //int          ret   = -1;                                                                   
        data_pair_t *pairs = NULL;                                                                 
        data_pair_t *next  = NULL;                                                                 
		int i = 0;
		fsnd->xattr_array = NULL;
                                                                                                   
        pairs = dict->members_list;                                                                
        //while (pairs) {                                                                            
                gf_log ("", GF_LOG_ERROR, "key=[%s], value=[%02x%02x]", pairs->key, pairs->value->data[14], pairs->value->data[15]); 
                next = pairs->next;                                                                

				fsnd->xattr_array = GF_CALLOC (1, sizeof (struct _xattr), gf_metadata_mt_char);
				fsnd->xattr_array->key = GF_CALLOC (1, sizeof (struct _xattr), gf_metadata_mt_char);
				fsnd->xattr_array->value = GF_CALLOC (1, sizeof (struct _xattr), gf_metadata_mt_char);

				fsnd->xattr_array->key = pairs->key;
				fsnd->xattr_array->value = pairs->value->data;

/*
				fsnd->xattr_array->next =  fsnd->xattr_array;
				fsnd->xattr_array->next->prev = fsnd->xattr_array;
				fsnd->xattr_array->prev->next = fsnd->xattr_array;
*/

				i++;

 //               pairs = next;                                                                      
        //} 
//		fsnd->xattr_array->next =  NULL;
		fsnd->xattr_cnt  = i ;

#endif
	return 0;
}

/* Emd add */

metadata_node_table_t *
metadata_node_table_init()
{
    uint32_t                   i   = 0;
    uint32_t                   ret = -1;
    metadata_node_table_t     *node_table;

    node_table = GF_CALLOC(1, sizeof(*node_table), gf_metadata_mt_table_t);
	if(!node_table)
		goto out;

    node_table->hashsize=NODEHASHSIZE; 

    node_table->fsnodes_list=(void *)GF_CALLOC (NODEHASHSIZE, sizeof (struct list_head),gf_metadata_mt_fsnode_t);
	if(!node_table->fsnodes_list)
		goto out;

    for(i=0;i<node_table->hashsize;i++)
    {
            INIT_LIST_HEAD(&node_table->fsnodes_list[i]);
    }

    node_table->fsedges_list=(void *)GF_CALLOC (NODEHASHSIZE, sizeof (struct list_head),gf_metadata_mt_fsedge_t);
	if(!node_table->fsedges_list)
		goto out;

    for(i=0;i<node_table->hashsize;i++)
    {
            INIT_LIST_HEAD(&node_table->fsedges_list[i]);
    }

    node_table->nodes=0;
    node_table->dirnodes=0;
    node_table->filenodes=0;
    node_table->total_metadata_mem=0;

	ret = 0;

out:
	return node_table;
}

void _add_fsnode_to_hash_table(uuid_t gfid , fsnode *p, fsedge *eg, metadata_node_table_t *table) {
	uint32_t nodepos = 0;

	if (p == NULL && eg == NULL)
		return;

//硬链接时，只需要新增一个fsedge 
	if (p == NULL && eg != NULL)
		goto onlyeg;

	p->parents = eg;    /* 指向fsedge */
	nodepos = NODEHASHPOS(p->gfid);

	INIT_LIST_HEAD(&p->fsnd_list);
	list_add(&p->fsnd_list, &table->fsnodes_list[nodepos]);
	
	table->nodes++;
	if (S_ISDIR (p->stat.st_mode)) {
		table->dirnodes++;
	} else {
		table->filenodes++;
	}

/* Add by hf@20150421 for fseg_hashtable */
	//fsedge **fseg_hashtable = table->fseg_hashtable; // Add @20150421 for fseg_hashtable
onlyeg:

	if(!eg){
		nodepos = NODEHASHPOS(p->gfid);
	}else{
		nodepos = NODEHASHPOS(gfid);
		INIT_LIST_HEAD(&eg->fseg_list);
		list_add(&eg->fseg_list, &table->fsedges_list[nodepos]);
	}
/* End add */

/*
	if(eg)
		gf_log ("", GF_LOG_ERROR, "<---------------------------------nodepos-=[%d]----mode=[%d] eg->name=[%s]", nodepos, p->stat.st_mode, eg->name);
*/

	return;
}

void add_fsnode_to_hash_table(uuid_t gfid, fsnode *p, fsedge *eg, metadata_node_table_t *table) {

        //if (!p || !table) {
        if ((!p && !eg) || !table) {
                return;
        }

        LOCK (&table->lock);
        {
               _add_fsnode_to_hash_table(gfid, p, eg, table);
        }
        UNLOCK (&table->lock);
        return;
}

/* Note:    Add by HF@20150507
 * Decribe: 创建根目录的fsnode 
 */
fsnode *fsnodes_rootnode_create(loc_t *loc, struct iatt *iatt, dict_t *dict)
{
    fsnode        *new_fsnd = NULL;
    new_fsnd = fsnode_new();
	if(!new_fsnd)
		goto out;

    uuid_copy(new_fsnd->gfid, loc->gfid);
    new_fsnd->xattr_cnt = 0;
    new_fsnd->parents  = NULL;
    new_fsnd->children = NULL;
	iatt_to_stat(iatt, &new_fsnd->stat);
    fsnode_xattr_set(dict, new_fsnd);
	
	INIT_LIST_HEAD(&new_fsnd->fsnd_list);

out:
    return new_fsnd;
}

fsnode *fsnodes_node_create(dict_t *dict,  gf_dirent_t  *entry ,fsedge *fseg, fsnode *fsnd)
{
    fsnode        *new_fsnd = NULL;
    new_fsnd = fsnode_new();
	if(!new_fsnd)
		goto out;

	INIT_LIST_HEAD(&new_fsnd->fsnd_list);

    uuid_copy(new_fsnd->gfid, entry->d_stat.ia_gfid);
    iatt_to_stat(&entry->d_stat, &new_fsnd->stat);

    new_fsnd->xattr_cnt = 0;
    fsnode_xattr_set(dict, new_fsnd);
/*
	while(new_fsnd->xattr_array){
		gf_log ("", GF_LOG_ERROR, "<-------------------new_fsnd entry->d_ino=[%ld], key=[%s]-value=[%s]--xattr_cnt=[%d]-------->", 
				entry->d_ino,new_fsnd->xattr_array->key, new_fsnd->xattr_array->value, new_fsnd->xattr_cnt);
		new_fsnd->xattr_array = new_fsnd->xattr_array->next;
	}
*/

    new_fsnd->children = NULL;
    new_fsnd->parents = NULL;

    if (!IA_ISDIR (entry->d_stat.ia_type))
    {
        new_fsnd->children = NULL;
        //new_fsnd->next = NULL;
    }

out:
    return new_fsnd;
}

fsedge *fsedges_edge_create(gf_dirent_t  *entry,
		fsnode *per_fsnd, fsnode *nxt_fsnd, const char *lkname, int hdflag)
{

    fsedge         *new_fseg = NULL;
    fsedge         *hard_fseg = NULL;
    new_fseg = fsedge_new(entry->d_name, lkname);
	if(!new_fseg)
		goto out;

	INIT_LIST_HEAD(&new_fseg->fseg_list);

    strcpy(new_fseg->name, entry->d_name);
    new_fseg->nleng = strlen(entry->d_name);
    new_fseg->child = nxt_fsnd;
    new_fseg->parent =  per_fsnd;
    per_fsnd->children =  new_fseg;

/* Add 20150417 */
    new_fseg->d_ino = entry->d_ino;
    new_fseg->d_off = entry->d_off;
    new_fseg->d_len = entry->d_len;
    new_fseg->d_type = entry->d_type;
    new_fseg->d_sync = entry->d_sync;
/* End add */

	//for hard link 
	if (IA_ISREG (ia_type_from_st_mode (nxt_fsnd->stat.st_mode)) && hdflag){ 
		gf_log("", GF_LOG_ERROR, "fsnode hard link first_fseg->name=[%s], d_name=[%s]", 
					nxt_fsnd->parents->name, entry->d_name);
		hard_fseg = nxt_fsnd->parents;

		while(hard_fseg->nextparent){
			gf_log("", GF_LOG_ERROR, "fsnode hard link behind first fseg->name=[%s], d_name=[%s]", 
					hard_fseg->nextparent->name, entry->d_name);
			new_fseg->prevparent =  &nxt_fsnd->parents->nextparent;
			hard_fseg = hard_fseg->nextparent;
		}

		hard_fseg->nextparent = new_fseg;
		gf_log("", GF_LOG_ERROR, "fsnode hard link new_fseg->name=[%s], d_name=[%s]", 
				new_fseg->name, entry->d_name);
	}else{
		nxt_fsnd->parents = new_fseg;
    	new_fseg->nextchild = NULL;
    	new_fseg->nextparent = NULL;
    	new_fseg->prevchild = NULL;   /* 主要用于操作fsedge */
    	new_fseg->prevparent = NULL;
	}

	if (IA_ISLNK (entry->d_stat.ia_type) && lkname){
		strcpy(new_fseg->linkname, lkname);
		gf_log("", GF_LOG_ERROR, "fsnode link name =[%s]", new_fseg->linkname);
	}


	gf_log ("", GF_LOG_ERROR, "1------------------fsedge->name=[%s]----", new_fseg->name);

out:
    return new_fseg;
}


void showFsnodes(metadata_private_t  *priv)
{
	uint32_t   i    = 0 ;
	fsnode    *fsnd = NULL;
	fsnode    *tmpfsnd = NULL;
gf_log ("", GF_LOG_ERROR, "<------------------------------------Begin show fsnode---------------------------------->");

gf_log ("", GF_LOG_ERROR, "<--------priv->nodes=[%d]", priv->table->nodes);
gf_log ("", GF_LOG_ERROR, "<--------priv->dirnodes=[%d]", priv->table->dirnodes);
gf_log ("", GF_LOG_ERROR, "<--------priv->filenodes=[%d]", priv->table->filenodes);
//gf_log ("", GF_LOG_ERROR, "<--------priv->total_metadata_mem=[%ld]", priv->table->total_metadata_mem);
	for (i = 0; i < NODEHASHSIZE; i++)
	{

		if(list_empty(&priv->table->fsnodes_list[i]))
			continue;

		list_for_each_entry_safe(fsnd, tmpfsnd, &priv->table->fsnodes_list[i], fsnd_list){
			if(!__is_root_gfid (fsnd->gfid))
			gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->name=[%s] fsnode->gfid=[%s]", 
				i,fsnd->parents->name, uuid_utoa(fsnd->gfid));
		}
	}

gf_log ("", GF_LOG_ERROR, "<------------------------------------End  ----------------------------------->");
}

void showFsedges(metadata_private_t  *priv)
{
	uint32_t   i    = 0 ;
	fsedge    *fseg = NULL;
	fsedge    *tmpfseg = NULL;
	fsedge    *hard_fseg = NULL;

	for (i = 0; i < NODEHASHSIZE; i++)
	{

		if(list_empty(&priv->table->fsedges_list[i]))
			continue;

		list_for_each_entry_safe(fseg, tmpfseg, &priv->table->fsedges_list[i], fseg_list){
            gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->name=[%s],linkname=[%s] parent->gfid=[%02x%02x], child->gfid=[%02x%02x] ", 
						i,fseg->name, fseg->linkname, fseg->parent->gfid[14], fseg->parent->gfid[15],
							fseg->child->gfid[14], fseg->child->gfid[15]);
				//for hard link 
				if (IA_ISREG (ia_type_from_st_mode (fseg->child->stat.st_mode))){ 
					hard_fseg = fseg;
					while(hard_fseg->nextparent){
						gf_log("", GF_LOG_ERROR, "fsnode hard link behind first fseg->name=[%s]", hard_fseg->nextparent->name);
						hard_fseg = hard_fseg->nextparent;
					}
				}
		}
	}

}

#if 0
void showLfsedge(metadata_private_t  *priv)
{
    int i = 0;
gf_log ("", GF_LOG_ERROR, "<---------------------------------[fsedge L ]---Begin----------------------------------->");
//gf_log ("", GF_LOG_ERROR, "<--------priv->total_metadata_mem=[%ld]", priv->table->total_metadata_mem);
    for(i = 0; i < (1<<16); i++)
    {
        if(priv->table->fseg_hashtable[i] != NULL)
        {
            gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->name=[%s] ",
                        i,priv->table->fseg_hashtable[i]->name);
            if(priv->table->fseg_hashtable[i]->nextchild!= NULL)
            {
                gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->nextparent->name=[%s] ",
                        i,priv->table->fseg_hashtable[i]->nextchild->name);
            }
			shownextLfseg(priv->table->fseg_hashtable[i]->nextchild, i);
        }
    }

gf_log ("", GF_LOG_ERROR, "<------------------------------------End  ----------------------------------->");

}
#endif

#if 0
void showRfsedge(metadata_private_t  *priv)
{
    int i = 0;
	fsedge  *fseg = NULL;
	gf_log ("", GF_LOG_ERROR, "<---------------------------------[fsedge R ]---Begin----------------------------------->");
    for(i = 0; i < NODEHASHSIZE; i++)
    {
		fseg = priv->table->fseg_hashtable[i];
		while(fseg != NULL){
            gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->name=[%s] parent->gfid=[%02x%02x], child->gfid=[%02x%02x] ", 
						i,fseg->name, fseg->parent->gfid[14], fseg->parent->gfid[15],
							fseg->child->gfid[14], fseg->child->gfid[15]);
		fseg = fseg->nextparent;
		}
#endif
#if 0
        if(fseg != NULL)
        {
            gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->name=[%s] parent->gfid=[%02x%02x], child->gfid=[%02x%02x] ", 
						i,fseg->name, fseg->parent->gfid[14], fseg->parent->gfid[15],
							fseg->child->gfid[14], fseg->child->gfid[15]);
			// 向前遍历
			while(fseg->nextparent != NULL){
            gf_log ("", GF_LOG_ERROR, "<------i=[%d],-fsedge->nextparent->name=[%s] parent->gfid=[%02x%02x], child->gfid=[%02x%02x] ", 
						i,fseg->nextparent->name, fseg->nextparent->parent->gfid[14], fseg->nextparent->parent->gfid[15],
							fseg->nextparent->child->gfid[14], fseg->nextparent->child->gfid[15]);
				fseg = fseg->nextparent;
			}

#endif
#if 0
			//向后遍历 
			while(fseg->nextchild!= NULL){
                gf_log ("", GF_LOG_ERROR, "<------i=[%d], fsedge->nextchild->name=[%s]", i,fseg->name);
				fseg = fseg->nextchild;
			}
        }
#endif
#if 0
    }

gf_log ("", GF_LOG_ERROR, "<------------------------------------End  ----------------------------------->");

}
#endif

static int
_metadata_fd_ctx_get (fd_t *fd, xlator_t *this, struct mtdata_fd **pfd_p)
{
        uint64_t          tmp_pfd = 0;
        struct mtdata_fd  *pfd = NULL;
        int               ret = -1;
        //char             *real_path = NULL;
        //int               _fd = -1;
        //DIR              *dir = NULL;

        ret = __fd_ctx_get (fd, this, &tmp_pfd);
gf_log ("", GF_LOG_ERROR, "---------ret=[%d]", ret);
        if (ret == 0) {
gf_log ("", GF_LOG_ERROR, "---------tmp_pfd=[%ld]", tmp_pfd);
                pfd = (void *)(long) tmp_pfd;
                ret = 0;
                goto out;
        }

        if (!fd_is_anonymous(fd))
                /* anonymous fd */
                goto out;
#if 0

        MAKE_HANDLE_PATH (real_path, this, fd->inode->gfid, NULL);

        pfd = GF_CALLOC (1, sizeof (*pfd), gf_posix_mt_posix_fd);
        if (!pfd) {
                goto out;
        }
        pfd->fd = -1;

        if (fd->inode->ia_type == IA_IFDIR) {
                dir = opendir (real_path);
                if (!dir) {
                        GF_FREE (pfd);
                        pfd = NULL;
                        goto out;
                }
                _fd = dirfd (dir);
        }

        if (fd->inode->ia_type == IA_IFREG) {
                _fd = open (real_path, O_RDWR|O_LARGEFILE);
                if (_fd == -1) {
                        GF_FREE (pfd);
                        pfd = NULL;
                        goto out;
                }
        }

        pfd->fd = _fd;
        pfd->dir = dir;

        ret = __fd_ctx_set (fd, this, (uint64_t) (long) pfd);
        if (ret != 0) {
                if (_fd != -1)
                        close (_fd);
                if (dir)
                        closedir (dir);
                GF_FREE (pfd);
                pfd = NULL;
                goto out;
        }
#endif

        ret = 0;
out:
        if (pfd_p)
                *pfd_p = pfd;
        return ret;
}


int
metadata_fd_ctx_get (fd_t *fd, xlator_t *this, struct mtdata_fd **pfd)
{
        int   ret;

        LOCK (&fd->inode->lock);
        {
                ret = _metadata_fd_ctx_get (fd, this, pfd);
        }
        UNLOCK (&fd->inode->lock);

        return ret;
}

fsnode *
get_next_fsnode(metadata_node_table_t * table, uuid_t  gfid)
{
        uint32_t   posnode = 0;
        posnode = NODEHASHPOS(gfid);

        fsnode  *fsnd = NULL;
        list_for_each_entry(fsnd,  &table->fsnodes_list[posnode], fsnd_list){
            if (!uuid_compare (fsnd->gfid, gfid)) {
                if(!__is_root_gfid (gfid))
                    gf_log ("", GF_LOG_INFO, "1-find_next_fsdnode look_name=[%s] gfid=[%02x%02x] is the  same  ", 
						fsnd->parents->name, gfid[14],gfid[15]);
                goto out;
            }
        }

out:
        return fsnd;
}

fsedge *
get_next_fsedge(metadata_node_table_t * table, uuid_t  gfid, const char *name )
{
        uint32_t   posnode = 0;
        posnode = NODEHASHPOS(gfid);

        fsedge  *fseg = NULL;

        if (list_empty (&table->fsedges_list[posnode]))
            goto out;

        list_for_each_entry(fseg,  &table->fsedges_list[posnode],  fseg_list){
            if(!strcmp(name, fseg->name)){
                gf_log ("", GF_LOG_INFO, "2-fseg parent fsdnode=[%02x%02x] name=[%s]", 
						fseg->child->gfid[14], fseg->child->gfid[15], fseg->name);
                goto out;
            }
        }

        fseg = NULL;
out:
        return fseg;
}

fsnode *fsnodes_node_add(struct iatt  *d_stat)
{
    fsnode        *new_fsnd = NULL;
    new_fsnd = fsnode_new();

    uuid_copy(new_fsnd->gfid, d_stat->ia_gfid);
    iatt_to_stat(d_stat,&new_fsnd->stat);

    new_fsnd->xattr_cnt = 0;
    new_fsnd->children = NULL;
    new_fsnd->parents = NULL;

    if (!IA_ISDIR (d_stat->ia_type))
    {
        new_fsnd->children = NULL;
    }
 
    return new_fsnd;
}

fsedge *fsedges_edge_add(struct dirent *entry, 
		fsnode *per_fsnd, fsnode *nxt_fsnd, const char *lkname)
{

    fsedge         *new_fseg = NULL;
    fsedge         *hard_fseg = NULL;
    new_fseg = fsedge_new(entry->d_name, lkname);

    strcpy(new_fseg->name, entry->d_name);
    new_fseg->nleng = strlen(entry->d_name);
    new_fseg->child = nxt_fsnd;
    new_fseg->parent =  per_fsnd;
    per_fsnd->children =  new_fseg;

    new_fseg->d_ino = entry->d_ino;
    new_fseg->d_off = entry->d_off;
    new_fseg->d_len = entry->d_reclen;
    new_fseg->d_type = entry->d_type;
    //new_fsnd->d_sync = entry->d_sync;
    
	//for hard link 
	if (IA_ISREG (entry->d_type)){ 
		gf_log("", GF_LOG_ERROR, "fsnode hard link first_fseg->name=[%s], d_name=[%s]", nxt_fsnd->parents->name, entry->d_name);
		hard_fseg = nxt_fsnd->parents;
		while(hard_fseg->nextparent){
			gf_log("", GF_LOG_ERROR, "fsnode hard link behind first fseg->name=[%s], d_name=[%s]", hard_fseg->nextparent->name, entry->d_name);
			new_fseg->prevparent =  &nxt_fsnd->parents->nextparent;
			hard_fseg = hard_fseg->nextparent;
		}
		hard_fseg->nextparent = new_fseg;
		gf_log("", GF_LOG_ERROR, "fsnode hard link new_fseg->name=[%s], d_name=[%s]", new_fseg->name, entry->d_name);
	}else{
		nxt_fsnd->parents = new_fseg;

    	new_fseg->nextchild = NULL;
    	new_fseg->nextparent = NULL;
    	new_fseg->prevchild = NULL;   /* 主要用于操作fsedge */
    	new_fseg->prevparent = NULL;
	}

	// for symlink
	if (IA_ISLNK (entry->d_type) && lkname){
		strcpy(new_fseg->linkname, lkname);
		gf_log("", GF_LOG_ERROR, "fsnode symlink name =[%s], d_name=[%s]", new_fseg->linkname, entry->d_name);
	}
	
	gf_log ("", GF_LOG_ERROR, "1------------------fsedge->name=[%s]----", new_fseg->name);

    return new_fseg;
}

void fsnodes_node_del(metadata_node_table_t *table, uuid_t  gfid, ia_type_t ia_type)
{
    uint32_t     nodepos = 0;
    fsnode      *fsnd    = NULL;
    fsnode      *tmpfsnd    = NULL;

    nodepos = NODEHASHPOS(gfid);

    if (list_empty (&table->fsnodes_list[nodepos]))
        goto out;

    list_for_each_entry_safe(fsnd, tmpfsnd, &table->fsnodes_list[nodepos], fsnd_list){
        if(fsnd){
            if(!uuid_compare (fsnd->gfid, gfid)){
                gf_log ("", GF_LOG_ERROR, "delete from fsnode where i=[%d],next->name=[%s] gfid=[%02x%02x]",
                        nodepos,fsnd->parents->name, fsnd->gfid[14], fsnd->gfid[15]);
                list_del(&fsnd->fsnd_list);
                fsnode_destroy(fsnd);
                break;

            }
        }
    }

    table->nodes--;
    if (S_ISDIR (ia_type)) {
        table->dirnodes--;
    } else {
        table->filenodes--;
    }
out:
    return ;
}

void fsnodes_edge_del(metadata_node_table_t *table, uuid_t  gfid, const char *name)
{
    uint32_t     nodepos = 0;
    fsedge      *fseg    = NULL;
    fsedge      *tmpfseg    = NULL;

    nodepos = NODEHASHPOS(gfid);

    if (list_empty (&table->fsedges_list[nodepos]))
        goto out;

    list_for_each_entry_safe(fseg, tmpfseg, &table->fsedges_list[nodepos], fseg_list){
        if(fseg){
            if(!strcmp(fseg->name, name)){
                gf_log ("", GF_LOG_ERROR, "delete from fsedge where i=[%d],fseg->name=[%s], gfid=[%02x%02x]",
                        nodepos,fseg->name, fseg->child->gfid[14], fseg->child->gfid[15]);
                list_del(&fseg->fseg_list);
                fsedge_destroy(fseg);
                break;
            }
        }
    }

out:
    return;
}

//void *fsnodes_node_upd(metadata_node_table_t * table, struct iatt  *d_stat)
void fsnodes_node_upd(fsnode *fsnd , struct iatt  *d_stat, int hdflag)
{
	fsedge  *hard_fseg = NULL;
	if(hdflag){
		hard_fseg = fsnd->parents;
		while(hard_fseg->nextparent){
			gf_log("", GF_LOG_ERROR, "fsnode hard link name=[%s] updated ", hard_fseg->name);
    		iatt_to_stat(d_stat,&fsnd->stat);
			hard_fseg = hard_fseg->nextparent;
		}
	}else{
    	iatt_to_stat(d_stat,&fsnd->stat);
	}
//缺少扩展属性更新
	fsnd->xattr_cnt = 0;

}

